Zeesoft Development Kit
=======================
The Zeesoft Development Kit (ZDK) is an open source library for Java application development.  

It provides support for;  
 * Extended StringBuilder manipulation and validation  
 * Basic file writing and reading  
 * HTTP requests  
 * CSV data  
 * JSON data  
 * Multi threading  
 * Application message handling
 * Basic matrix mathematics  
 * Genetic algorithms  
 * Neural networks  
 * [Hierarchical Temporal Memory](https://numenta.com/)  
   * Sparse distributed representations  
   * Spatial pooling  
   * Temporal memory  
   * SDR streaming  
   * Anomaly detection  
   * Value classification and prediction  
 * Self documenting and testing libraries  

**Release downloads**  
Click [here](https://github.com/DyzLecticus/Zeesoft/raw/master/V4.0/ZDK/releases/zdk-0.9.0.zip) to download the latest ZDK release (version 0.9.0).  
All ZDK releases can be downloaded [here](https://github.com/DyzLecticus/Zeesoft/raw/master/V4.0/ZDK/releases/).  
*All jar files in the release include source code and build scripts.*  

**Self documenting and self testing**  
The tests used to develop this libary are also used to generate this README file.  
Run the [ZDK](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/ZDK.java) class as a java application to print this documentation to the standard out.  
Click [here](#test-results) to scroll down to the test result summary.  

nl.zeesoft.zdk.test.impl.TestZStringEncoder
-------------------------------------------
This test shows how to use the *ZStringEncoder* to generate a key and then use that to encode and decode a text.

**Example implementation**  
~~~~
// Create the ZStringEncoder
ZStringEncoder encoder = new ZStringEncoder("Example text to be encoded.");
// Generate a key
String key = encoder.generateNewKey(1024);
// Use the key to encode the text
encoder.encodeKey(key,0);
// Use the key to decode the encoded text
encoder.decodeKey(key,0);
~~~~

This encoding mechanism can be used to encode and decode passwords and other sensitive data.
The minimum key length is 64. Longer keys provide stronger encoding.

Class references;  
 * [TestZStringEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestZStringEncoder.java)
 * [ZStringEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/ZStringEncoder.java)

**Test output**  
The output of this test shows the generated key, the input text, the encoded text, and the decoded text.
~~~~
Key: 4549575610670807586052853089500998735044726862813280594516366485
Input text: Hello, my name is 'Dyz Lecticus'. How are you feeling today? :-) (Don't you know how to: [re;spond]!).

Key encoded text: OiZjFjfnmkHk2i~kTgef5kakxgYlifElwkllujEf0jiihluj0hrgSm0m~j6fJgwmxmrlYkBiVj4e0iAjnlLgnl#mQkRg3lMgji3h2lngokYlujTj1gAkTijkGjPi#fSedh4i5iinlkCkkkqjTgsgbkajvg8lwgSlejsm:ktgLichvmci6gjgQm6mYi4fGgAnwnumjlrhIihf0
Key decoded text: Hello, my name is 'Dyz Lecticus'. How are you feeling today? :-) (Don't you know how to: [re;spond]!).

ASCII encoded text: 42,24,59,48,66,63,2,-28,67,73,-10,50,55,61,59,-28,63,67,-10,-21,26,73,80,-28,34,53,57,56,63,51,75,55,-3,-2,-10,12,69,71,-10,37,72,53,-10,61,69,69,-10,42,59,53,66,45,68,55,-10,56,69,52,55,61,21,-16,16,-15,-1,-16,-2,8,69,62,-3,56,-10,73,69,57,-10,59,68,51,77,-16,62,51,77,-16,74,51,16,-16,49,54,59,11,73,52,69,62,58,33,-9,-7,4
ASCII decoded text: Hello, my name is 'Dyz Lecticus'. How are you feeling today? :-) (Don't you know how to: [re;spond]!).
~~~~

nl.zeesoft.zdk.test.impl.TestZStringSymbolParser
------------------------------------------------
This test shows how to use the *ZStringSymbolParser* to parse symbols (words and punctuation) from a certain text.

**Example implementation**  
~~~~
// Create the ZStringSymbolParser
ZStringSymbolParser parser = new ZStringSymbolParser("Example text.");
// Parse the string
List<String> symbols = parser.toSymbolsPunctuated();
~~~~

Class references;  
 * [TestZStringSymbolParser](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestZStringSymbolParser.java)
 * [ZStringSymbolParser](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/ZStringSymbolParser.java)

**Test output**  
The output of this test shows the input text and the parsed symbols separated by spaces.
~~~~
Input text: Hello, my name is 'Dyz Lecticus'. How are you feeling today? :-) (Don't you know how to: [re;spond]!).
Parsed symbols: Hello , my name is ' Dyz Lecticus ' . How are you feeling today ? :-) ( Don't you know how to : [re;spond] ! ) .
~~~~

nl.zeesoft.zdk.test.impl.TestCsv
--------------------------------
This test shows how to create a *CsvFile* instance from a CSV string.

**Example implementation**  
~~~~
// Create CSV object
CsvFile csv = new CsvFile();
// Parse CSV from string
csv.fromStringBuilder(new ZStringBuilder("test,qwer,123\n"));
~~~~

Class references;  
 * [TestCsv](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestCsv.java)
 * [CsvFile](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/CsvFile.java)

**Test output**  
The output of this test shows the string input and the resulting number of rows and columns.  
~~~~
Input:
test,qwer,123
test,qwer,123,qwer
"t,e\"\nst",qwer,123
"t,e""\nst""",qwer,123

Rows: 4, columns: 3
~~~~

nl.zeesoft.zdk.test.impl.TestJson
---------------------------------
This test shows how to create a *JsFile* instance from a JSON string.

**Example implementation**  
~~~~
// Create JSON object
JsFile json = new JsFile();
// Parse JSON from string
json.fromStringBuilder(new ZStringBuilder("{\"command\":\"doStuff\"}"));
~~~~

Class references;  
 * [TestJson](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestJson.java)
 * [JsFile](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/json/JsFile.java)

**Test output**  
The output of this test shows the string input and the resulting JSON structure.  
~~~~
Input:
{
    "qwerValue" : "qwerqwer",
    "qwerObject1" : {"qwerName":"name1" ,"qwerNumber": 1234},
    "qwerObject2" : {
        "qwerName": "name2",
        "qwerNumber": 12345,
        "qwerArray": [],
        "qwerSubObject1": {qwerqwer:"qwer qwer1",qwertqwert:"qwert qwert1"},
        "qwerSubObject2": {qwerqwer:"qwer qwer2",qwertqwert:"qwert qwert2"},
        "qwerObjectArray": [{asdfasdf:"asdf","qwer":["qwerqwer","qwerqwerqwer","qwerqwerqwerqwer"]},{asdf:"asdfasdf"}]
    }
}

JSON structure:
{
  "qwerValue": "qwerqwer",
  "qwerObject1": {
    "qwerName": "name1",
    "qwerNumber": 1234
  },
  "qwerObject2": {
    "qwerName": "name2",
    "qwerNumber": 12345,
    "qwerArray": [],
    "qwerSubObject1": {
      "qwerqwer": "qwer qwer1",
      "qwertqwert": "qwert qwert1"
    },
    "qwerSubObject2": {
      "qwerqwer": "qwer qwer2",
      "qwertqwert": "qwert qwert2"
    },
    "qwerObjectArray": [
      {
        "asdfasdf": "asdf",
        "qwer": [
          "qwerqwer",
          "qwerqwerqwer",
          "qwerqwerqwerqwer"
        ]
      },
      {
        "asdf": "asdfasdf"
      }
    ]
  }
}
~~~~

nl.zeesoft.zdk.test.impl.TestZHttpRequest
-----------------------------------------
This test shows how to use a *ZHttpRequest* instance to call a JSON API and return the response as a *JsFile*.
A *ZHttpRequest* instance can also be used to make regular GET, POST and PUT requests.

**Example implementation**  
~~~~
// Create ZHttpRequest
ZHttpRequest http = new ZHttpRequest("GET","http://url.domain");
// Send the request
JsFile json = http.sendJsonRequest();
~~~~

This test uses the *MockZHttpRequest*.

Class references;  
 * [TestZHttpRequest](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestZHttpRequest.java)
 * [MockZHttpRequest](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/MockZHttpRequest.java)
 * [ZHttpRequest](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/http/ZHttpRequest.java)
 * [JsFile](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/json/JsFile.java)

**Test output**  
The output of this test shows the JSON response of the *MockZHttpRequest*.  
~~~~
Response:
{
  "response": "JSON response"
}
~~~~

nl.zeesoft.zdk.test.impl.TestMessenger
--------------------------------------
This test reflects a default implementation of the *Messenger* combined with the *WorkerUnion*.

**Example implementation**  
~~~~
// Create a factory
ZDKFactory factory = new ZDKFactory();
// Get the messenger from the factory
Messenger messenger = factory.getMessenger();
// Add a debug message
messenger.debug(this,"Example debug message");
// Add a warning message
messenger.warn(this,"Example warning message");
// Enable debug message printing
messenger.setPrintDebugMessages(true);
// Start the messenger
messenger.start();
// Add an error message
messenger.error(this,"Example error message");
// Stop the messenger
messenger.stop();
// Ensure all application workers are stopped
factory.getWorkerUnion(messenger).stopWorkers();
// Trigger the messenger to print the remaining messages
messenger.handleMessages();
~~~~

The *Messenger* can be used to log debug, warning and error messages and print them to the standard and/or error out.
It implements the *Worker* to minimize wait time impact for threads that call the *Messenger*.
The *Messenger* is thread safe so it can be shared across the entire application.
Classes that implement the *MessengerListener* interface can subscribe to *Messenger* message printing events.
The *WorkerUnion* can be used to ensure all workers that have been started are stopped when stopping the application.
It will log an error if it fails to stop a worker.

This test uses the *MockMessenger*.

Class references;  
 * [TestMessenger](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestMessenger.java)
 * [MockMessenger](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/MockMessenger.java)
 * [Messenger](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/messenger/Messenger.java)
 * [MessengerListener](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/messenger/MessengerListener.java)
 * [Worker](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/thread/Worker.java)
 * [WorkerUnion](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/thread/WorkerUnion.java)

**Test output**  
The output of this test shows the standard output of the test log messages.
~~~~
2019-12-23 19:21:34:371 DBG nl.zeesoft.zdk.test.impl.TestMessengerListener: Test log debug message before Messenger has started
2019-12-23 19:21:34:671 ERR nl.zeesoft.zdk.test.impl.TestMessengerListener: Test log error message while Messenger is working
2019-12-23 19:21:34:671 ERR nl.zeesoft.zdk.test.impl.TestMessengerListener: Test log exception stack trace
java.lang.NumberFormatException: For input string: "A"
	at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)
	at java.lang.Integer.parseInt(Integer.java:580)
	at java.lang.Integer.parseInt(Integer.java:615)
	at nl.zeesoft.zdk.test.impl.TestMessenger.test(TestMessenger.java:83)
	at nl.zeesoft.zdk.test.Tester.test(Tester.java:71)
	at nl.zeesoft.zdk.test.LibraryObject.describeAndTest(LibraryObject.java:39)
	at nl.zeesoft.zdk.test.impl.ZDK.main(ZDK.java:52)

2019-12-23 19:21:34:982 WRN nl.zeesoft.zdk.test.impl.TestMessengerListener: Test log warning message after Messenger has stopped
~~~~

nl.zeesoft.zdk.test.impl.TestZMatrix
------------------------------------
This test shows how to use a *ZMatrix* to do matrix calculations and transformations.

**Example implementation**  
~~~~
// Create the matrix
ZMatrix m = new ZMatrix(2,3);
// Randomize the matrix
m.randomize();
// Print the matrix
System.out.println(m.getTable());
~~~~

Class references;  
 * [TestZMatrix](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestZMatrix.java)
 * [ZMatrix](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/ZMatrix.java)

**Test output**  
The output of this test shows the results of several matrix calculations and transformations.  
~~~~
Initial;
010.00 | 010.00 | 010.00
-------+--------+-------
010.00 | 010.00 | 010.00

Scalar multiplied by 3;
030.00 | 030.00 | 030.00
-------+--------+-------
030.00 | 030.00 | 030.00

Randomized;
-00.38 | 000.51 | -00.12
-------+--------+-------
-00.13 | -00.37 | -00.30

Randomized multiplied element wise;
-11.29 | 015.43 | -03.74
-------+--------+-------
-04.01 | -11.02 | -09.08

Matrix 1;
001.00 | 001.00 | 001.00
-------+--------+-------
002.00 | 002.00 | 002.00

Matrix 2;
003.00 | 003.00
-------+-------
004.00 | 004.00
-------+-------
005.00 | 005.00

Matrix multiplication of matrix 1 * matrix 2;
012.00 | 012.00
-------+-------
024.00 | 024.00

New randomized matrix;
-00.89 | -00.88 | -00.19
-------+--------+-------
000.13 | -00.57 | -00.79

Randomized matrix transposed;
-00.89 | 000.13
-------+-------
-00.88 | -00.57
-------+-------
-00.19 | -00.79
~~~~

nl.zeesoft.zdk.test.impl.TestGeneticCode
----------------------------------------
This test shows how to create, mutate and use a *GeneticCode*.

**Example implementation**  
~~~~
// Create the genetic code
GeneticCode genCode = new GeneticCode(100);
// Mutate 5 genes
genCode.mutate(5);
// Get the number of properties
int size = genCode.size();
// Get a property value
float f = genCode.get(4);
// Get a scaled integer property value
int i = genCode.getInteger(4,100);
~~~~

Class references;  
 * [TestGeneticCode](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestGeneticCode.java)
 * [GeneticCode](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/genetic/GeneticCode.java)

**Test output**  
The output of this test shows;  
 * A generated genetic code  
 * The mutated genetic code and the resulting scaled property values  
~~~~
Genetic code: 1559929372452448822880248876389670627848245651642367644302989305066312239894746826084818376576379189
Mutated code: 1559929352452448822880248876389680627848245651642367644372989301066312239894746826084818376576319189
                      ^                       ^                       ^      ^                               ^    

Scaled property values;
0: 729 <
1: 935 <
2: 189
3: 806 <
4: 62
5: 189
6: 784
7: 228
8: 559
9: 826
10: 882
11: 876 <
12: 763
13: 155
14: 947
15: 784
16: 651
17: 155
18: 663
19: 372 <
20: 248
21: 680 <
22: 576
23: 642
24: 763
25: 608
26: 189
27: 765
28: 481
29: 488
30: 992
31: 599
32: 876 <
Mutated property values: 7
~~~~

nl.zeesoft.zdk.test.impl.TestNeuralNet
--------------------------------------
This test shows how to create, train and use a *NeuralNet*.

**Example implementation**  
~~~~
// Create the neural net
NeuralNet nn = new NeuralNet(inputNeurons,hiddenLayers,hiddenNeurons,outputNeurons);
// Initialize the weights
nn.randomizeWeightsAndBiases();
nn.applyWeightFunctions();
// Get a new prediction
Prediction p = nn.getNewPrediction();
// Set the prediction inputs (0.0 - 1.0)
p.inputs[0] = 0.0F;
p.inputs[1] = 1.0F;
// Let the neural net predict the outputs
n.predict(p);
// Get a new test set
TestSet ts = nn.getNewTestSet();
// Get a new test
Test t = ts.addNewTest();
// Set the test inputs (0.0 - 1.0)
t.inputs[0] = 0.0F;
t.inputs[1] = 1.0F;
// Set the test expectations (0.0 - 1.0)
t.expectations[0] = 1.0F;
// Let the neural net predict the test outputs and calculate the error and loss
n.test(ts);
// Randomize the order of the tests
ts.randomizeOrder();
// Use the test set to train the neural net
n.train(ts);
// Repeat randomization and training until the network reaches the desired state
// ... or a maximum number of times because sometimes they fail to converge
~~~~

Class references;  
 * [TestNeuralNet](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestNeuralNet.java)
 * [NeuralNet](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/NeuralNet.java)
 * [Prediction](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/Prediction.java)
 * [TestSet](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/TestSet.java)
 * [Test](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/Test.java)

**Test output**  
The output of this test shows;  
 * The test results for 2 XOR neural net implementations before and after training.  
 * The second neural net JSON structure.  
~~~~
Neural net activator: nl.zeesoft.zdk.functions.ZLeakyReLU, learning rate: 0.1
Initial test results;
  Input: [0.00|0.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [1.00|1.00], output: [0.04], expectation: [0.00], error: -0.04, loss: 0.036690872
  Input: [0.00|1.00], output: [0.06], expectation: [1.00], error: 0.94, loss: 0.9441594
  Input: [1.00|0.00], output: [-0.00], expectation: [1.00], error: 1.00, loss: 1.0000138
  Average error: 0.50, average loss: 0.50, success: false
Latest test results;
  Input: [1.00|1.00], output: [0.06], expectation: [0.00], error: -0.06, loss: 0.0640377
  Input: [0.00|0.00], output: [0.08], expectation: [0.00], error: -0.08, loss: 0.08447623
  Input: [1.00|0.00], output: [0.90], expectation: [1.00], error: 0.10, loss: 0.09844762
  Input: [0.00|1.00], output: [0.94], expectation: [1.00], error: 0.06, loss: 0.055139005
  Average error: 0.08, average loss: 0.08, success: true
Trained epochs: 2141, total average error: 769.28345, total average loss: 769.28345
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZLeakyReLU, output activator: nl.zeesoft.zdk.functions.ZSoftmaxTop, learning rate: 0.1
Initial test results;
  Input: [0.00|0.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [1.00|1.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [0.00|1.00], output: [0.00], expectation: [1.00], error: 1.00, loss: 1.0
  Input: [1.00|0.00], output: [0.00], expectation: [1.00], error: 1.00, loss: 1.0
  Average error: 0.50, average loss: 0.50, success: false
Latest test results;
  Input: [1.00|0.00], output: [1.00], expectation: [1.00], error: 0.00, loss: 0.0
  Input: [1.00|1.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [0.00|1.00], output: [1.00], expectation: [1.00], error: 0.00, loss: 0.0
  Input: [0.00|0.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Average error: 0.00, average loss: 0.00, success: true
Trained epochs: 128, total average error: 34.5, total average loss: 34.5

Neural net JSON;
{
  "inputNeurons": 2,
  "hiddenLayers": 1,
  "hiddenNeurons": 2,
  "outputNeurons": 1,
  "weightFunction": "nl.zeesoft.zdk.functions.ZWeightKaiming",
  "biasFunction": "nl.zeesoft.zdk.functions.ZWeightZero",
  "activator": "nl.zeesoft.zdk.functions.ZLeakyReLU",
  "outputActivator": "nl.zeesoft.zdk.functions.ZSoftmaxTop",
  "learningRate": 0.1,
  "values": [
    "2,1,0.0,0.0",
    "2,1,-0.0052964287,0.9863508",
    "1,1,0.0"
  ],
  "weights": [
    "1,1,0.0",
    "2,2,0.50879616,0.7607296,0.22874084,0.5742769",
    "1,2,-0.71236885,0.7524705"
  ],
  "biases": [
    "1,1,0.0",
    "2,1,-0.5296429,0.9863508",
    "1,1,-0.83031285"
  ]
}
~~~~

nl.zeesoft.zdk.test.impl.TestGeneticNN
--------------------------------------
This test shows how to use a *GeneticNN* to generate a *GeneticCode* and corresponding *NeuralNet*.
It uses a *TrainingProgram* to train and test the *NeuralNet*.
It keeps generating neural nets until it finds one that passes all the tests.

**Example implementation**  
~~~~
// Create the genetic neural network
GeneticNN gnn = new GeneticNN();
// Initialize the genetic neural network
gnn.initialize(inputNeurons,maxHiddenLayers,maxHiddenNeurons,outputNeurons,codePropertyStart);
// Generate a new genetic code and corresponding neural network
gnn.generateNewNN();
~~~~

Class references;  
 * [TestGeneticNN](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestGeneticNN.java)
 * [GeneticNN](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/genetic/GeneticNN.java)
 * [GeneticCode](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/genetic/GeneticCode.java)
 * [NeuralNet](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/NeuralNet.java)
 * [TrainingProgram](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/TrainingProgram.java)

**Test output**  
The output of this test shows the training program outputs of one or more generated XOR neural nets.  
~~~~
Neural net activator: nl.zeesoft.zdk.functions.ZTanH, output activator: nl.zeesoft.zdk.functions.ZLeakyReLU, learning rate: 0.0886
Initial test results;
  Input: [0.00|0.00], output: [0.04], expectation: [0.00], error: -0.04, loss: 0.04273048
  Input: [1.00|1.00], output: [-0.00], expectation: [0.00], error: 0.00, loss: 0.0031909798
  Input: [0.00|1.00], output: [0.12], expectation: [1.00], error: 0.88, loss: 0.8843068
  Input: [1.00|0.00], output: [-0.01], expectation: [1.00], error: 1.01, loss: 1.0051115
  Average error: 0.48, average loss: 0.48, success: false

00100 ---------------------------\ 113%
00200 ---------------------------| 113%
00300 --------------------------/ 111%
00400 ---------------------------\ 113%
00500 ---------------------------\ 114%
00600 ---------------------------| 114%
00700 ---------------------------| 114%
00800 ---------------------------\ 115%
00900 ----------------------------\ 116%
01000 ----------------------------| 116%
01100 ---------------------------/ 115%
01200 -------------------------/ 105%
01300 ---------------------------\ 115%
01400 -----------------------------\ 120%
01500 ----------------------------/ 116%
01600 ----------------------------\ 118%
01700 ---------------------------/ 115%
01800 ---------------------------/ 113%
01900 ----------------------------\ 119%
02000 ---------------------------/ 115%
02100 ---------------------------/ 113%
02200 ----------------------------\ 118%
02300 --------------------------/ 111%
02400 ----------------------------\ 117%
02500 ----------------------------\ 118%
02600 ----------------------------| 118%
02700 ----------------------------/ 117%
02800 ----------------------------| 117%
02900 ----------------------------/ 116%
03000 ---------------------------/ 115%
03100 -----------------------------\ 120%
03200 ----------------------------/ 116%
03300 ----------------------------\ 117%
03400 ----------------------------| 117%
03500 --------------------------/ 109%
03600 ---------------------------\ 114%
03700 ---------------------------/ 112%
03800 ----------------------------\ 119%
03900 ----------------------------/ 116%
04000 ----------------------------| 116%
04100 ----------------------------| 116%
04200 ----------------------------\ 117%
04300 ----------------------------\ 119%
04400 ----------------------------/ 117%
04500 ----------------------------/ 116%
04600 ----------------------------\ 117%
04700 ---------------------------/ 115%
04800 ----------------------------\ 116%
04900 --------------------------/ 111%
05000 ----------------------------\ 116%
05100 ----------------------------\ 119%
05200 ----------------------------/ 116%
05300 ----------------------------| 116%
05400 ----------------------------\ 118%
05500 -----------------------------\ 120%
05600 --------------------------/ 111%
05700 ----------------------------\ 116%
05800 --------------------------/ 111%
05900 ----------------------------\ 116%
06000 ----------------------------| 116%
06100 ----------------------------| 116%
06200 --------------------------/ 111%
06300 --------------------------/ 110%
06400 ---------------------------\ 112%
06500 ----------------------------\ 116%
06600 -------------------------/ 105%
06700 --------------------------\ 111%
06800 ---------------------------\ 115%
06900 ----------------------------\ 119%
07000 ----------------------------| 119%
07100 ----------------------------/ 116%
07200 -----------------------------\ 120%
07300 ---------------------------/ 115%
07400 ----------------------------\ 117%
07500 ----------------------------\ 118%
07600 ---------------------------/ 112%
07700 ---------------------------\ 115%
07800 --------------------------/ 109%
07900 ----------------------------\ 117%
08000 ---------------------------/ 115%
08100 ---------------------------/ 114%
08200 ---------------------------\ 115%
08300 -------------------------/ 106%
08400 ----------------------------\ 117%
08500 ----------------------------/ 116%
08600 ---------------------------/ 114%
08700 --------------------------/ 110%
08800 ----------------------------\ 116%
08900 ----------------------------\ 117%
09000 ----------------------------\ 118%
09100 ----------------------------/ 117%
09200 ----------------------------\ 119%
09300 ----------------------------/ 117%
09400 ----------------------------/ 116%
09500 ---------------------------/ 112%
09600 --------------------------/ 111%
09700 ----------------------------\ 116%
09800 ----------------------------\ 117%
09900 ----------------------------\ 118%
10000 ----------------------------| 118%

Latest test results;
  Input: [0.00|0.00], output: [0.56], expectation: [0.00], error: -0.56, loss: 0.5558498
  Input: [0.00|1.00], output: [0.41], expectation: [1.00], error: 0.59, loss: 0.59189504
  Input: [1.00|1.00], output: [0.57], expectation: [0.00], error: -0.57, loss: 0.56543064
  Input: [1.00|0.00], output: [0.42], expectation: [1.00], error: 0.58, loss: 0.5848608
  Average error: 0.57, average loss: 0.57, success: false
Trained epochs: 10000, total average error: 5570.357, total average loss: 5570.357
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZReLU, output activator: nl.zeesoft.zdk.functions.ZReLU, learning rate: 0.111600004
Initial test results;
  Input: [0.00|0.00], output: [0.89], expectation: [0.00], error: -0.89, loss: 0.88916475
  Input: [1.00|1.00], output: [0.89], expectation: [0.00], error: -0.89, loss: 0.88916475
  Input: [0.00|1.00], output: [0.89], expectation: [1.00], error: 0.11, loss: 0.110835254
  Input: [1.00|0.00], output: [0.89], expectation: [1.00], error: 0.11, loss: 0.110835254
  Average error: 0.50, average loss: 0.50, success: false

00100 -------------------------\ 105%
00200 -------------------------/ 104%
00300 -------------------------| 104%
00400 -------------------------\ 105%
00500 -------------------------/ 104%
00600 -------------------------\ 105%
00700 -------------------------/ 104%
00800 -------------------------\ 105%
00900 -------------------------| 105%
01000 -------------------------/ 104%
01100 -------------------------\ 105%
01200 -------------------------| 105%
01300 -------------------------/ 104%
01400 -------------------------| 104%
01500 -------------------------| 104%
01600 -------------------------\ 105%
01700 -------------------------| 105%
01800 -------------------------| 105%
01900 -------------------------| 105%
02000 -------------------------| 105%
02100 -------------------------| 105%
02200 -------------------------| 105%
02300 -------------------------/ 104%
02400 -------------------------\ 105%
02500 -------------------------/ 104%
02600 ------------------------/ 103%
02700 -------------------------\ 105%
02800 -------------------------| 105%
02900 -------------------------| 105%
03000 -------------------------\ 106%
03100 -------------------------/ 104%
03200 ------------------------/ 103%
03300 -------------------------\ 105%
03400 -------------------------/ 104%
03500 ------------------------/ 103%
03600 -------------------------\ 105%
03700 -------------------------/ 104%
03800 -------------------------\ 105%
03900 -------------------------| 105%
04000 -------------------------/ 104%
04100 -------------------------\ 105%
04200 -------------------------| 105%
04300 -------------------------| 105%
04400 -------------------------| 105%
04500 -------------------------\ 106%
04600 -------------------------/ 104%
04700 ------------------------/ 103%
04800 -------------------------\ 105%
04900 -------------------------| 105%
05000 -------------------------| 105%
05100 -------------------------/ 104%
05200 -------------------------\ 105%
05300 -------------------------/ 104%
05400 -------------------------\ 105%
05500 -------------------------/ 104%
05600 -------------------------| 104%
05700 -------------------------| 104%
05800 -------------------------| 104%
05900 -------------------------\ 105%
06000 -------------------------| 105%
06100 -------------------------| 105%
06200 -------------------------| 105%
06300 -------------------------| 105%
06400 -------------------------| 105%
06500 -------------------------| 105%
06600 -------------------------| 105%
06700 ------------------------/ 103%
06800 -------------------------\ 105%
06900 -------------------------| 105%
07000 -------------------------| 105%
07100 -------------------------| 105%
07200 -------------------------/ 104%
07300 -------------------------\ 105%
07400 -------------------------| 105%
07500 -------------------------| 105%
07600 -------------------------| 105%
07700 -------------------------| 105%
07800 -------------------------| 105%
07900 -------------------------| 105%
08000 -------------------------| 105%
08100 -------------------------| 105%
08200 -------------------------| 105%
08300 -------------------------| 105%
08400 -------------------------| 105%
08500 -------------------------| 105%
08600 -------------------------/ 104%
08700 -------------------------\ 105%
08800 ------------------------/ 103%
08900 -------------------------\ 104%
09000 -------------------------\ 105%
09100 -------------------------/ 104%
09200 -------------------------\ 105%
09300 -------------------------| 105%
09400 -------------------------| 105%
09500 -------------------------| 105%
09600 -------------------------| 105%
09700 -------------------------| 105%
09800 -------------------------| 105%
09900 -------------------------| 105%
10000 -------------------------| 105%

Latest test results;
  Input: [1.00|1.00], output: [0.51], expectation: [0.00], error: -0.51, loss: 0.50893146
  Input: [0.00|1.00], output: [0.45], expectation: [1.00], error: 0.55, loss: 0.5478653
  Input: [1.00|0.00], output: [0.51], expectation: [1.00], error: 0.49, loss: 0.48672354
  Input: [0.00|0.00], output: [0.57], expectation: [0.00], error: -0.57, loss: 0.5675948
  Average error: 0.53, average loss: 0.53, success: false
Trained epochs: 10000, total average error: 5262.862, total average loss: 5262.862
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZReLU, output activator: nl.zeesoft.zdk.functions.ZLeakyReLU, learning rate: 0.102400005
Initial test results;
  Input: [0.00|0.00], output: [-0.01], expectation: [0.00], error: 0.01, loss: 0.009665511
  Input: [1.00|1.00], output: [-0.01], expectation: [0.00], error: 0.01, loss: 0.009344494
  Input: [0.00|1.00], output: [-0.01], expectation: [1.00], error: 1.01, loss: 1.0097221
  Input: [1.00|0.00], output: [-0.01], expectation: [1.00], error: 1.01, loss: 1.0101657
  Average error: 0.51, average loss: 0.51, success: false

00100 -----------------------/ 99%
00200 -----------------------/ 98%
00300 -----------------------| 98%
00400 ------------------------\ 100%
00500 ------------------------\ 103%
00600 ------------------------| 103%
00700 ------------------------| 103%
00800 ------------------------| 103%
00900 ------------------------| 103%
01000 ------------------------| 103%
01100 ------------------------| 103%
01200 ------------------------/ 101%
01300 ------------------------\ 102%
01400 ------------------------\ 103%
01500 ------------------------/ 102%
01600 ------------------------\ 103%
01700 ------------------------| 103%
01800 ------------------------/ 102%
01900 ------------------------\ 103%
02000 ------------------------/ 102%
02100 ------------------------| 102%
02200 ------------------------\ 103%
02300 ------------------------| 103%
02400 ------------------------| 103%
02500 ------------------------/ 102%
02600 ------------------------\ 103%
02700 ------------------------| 103%
02800 ------------------------/ 102%
02900 ------------------------\ 103%
03000 ------------------------| 103%
03100 ------------------------/ 102%
03200 ------------------------\ 103%
03300 ------------------------| 103%
03400 ------------------------| 103%
03500 ------------------------| 103%
03600 ------------------------| 103%
03700 ------------------------| 103%
03800 ------------------------| 103%
03900 ------------------------| 103%
04000 ------------------------| 103%
04100 ------------------------/ 101%
04200 ------------------------\ 103%
04300 ------------------------/ 102%
04400 ------------------------\ 103%
04500 ------------------------/ 101%
04600 ------------------------\ 102%
04700 ------------------------| 102%
04800 ------------------------\ 103%
04900 ------------------------| 103%
05000 ------------------------| 103%
05100 ------------------------/ 102%
05200 ------------------------\ 103%
05300 ------------------------/ 101%
05400 ------------------------\ 103%
05500 ------------------------/ 101%
05600 ------------------------\ 103%
05700 ------------------------/ 102%
05800 ------------------------| 102%
05900 ------------------------\ 103%
06000 ------------------------| 103%
06100 ------------------------| 103%
06200 ------------------------/ 102%
06300 ------------------------| 102%
06400 ------------------------| 102%
06500 ------------------------\ 103%
06600 ------------------------/ 102%
06700 ------------------------| 102%
06800 ------------------------\ 103%
06900 ------------------------/ 102%
07000 ------------------------| 102%
07100 ------------------------\ 103%
07200 ------------------------| 103%
07300 ------------------------/ 102%
07400 ------------------------\ 103%
07500 ------------------------| 103%
07600 ------------------------| 103%
07700 ------------------------| 103%
07800 ------------------------| 103%
07900 ------------------------| 103%
08000 ------------------------/ 102%
08100 ------------------------\ 103%
08200 ------------------------/ 102%
08300 ------------------------| 102%
08400 ------------------------\ 103%
08500 ------------------------| 103%
08600 ------------------------/ 102%
08700 ------------------------| 102%
08800 ------------------------\ 103%
08900 ------------------------| 103%
09000 ------------------------/ 102%
09100 ------------------------\ 103%
09200 ------------------------| 103%
09300 ------------------------/ 102%
09400 ------------------------| 102%
09500 ------------------------\ 103%
09600 ------------------------| 103%
09700 ------------------------/ 102%
09800 ------------------------\ 103%
09900 ------------------------| 103%
10000 ------------------------/ 102%

Latest test results;
  Input: [1.00|1.00], output: [0.50], expectation: [0.00], error: -0.50, loss: 0.5049336
  Input: [0.00|0.00], output: [0.45], expectation: [0.00], error: -0.45, loss: 0.45322838
  Input: [0.00|1.00], output: [0.41], expectation: [1.00], error: 0.59, loss: 0.5931822
  Input: [1.00|0.00], output: [0.47], expectation: [1.00], error: 0.53, loss: 0.5324403
  Average error: 0.52, average loss: 0.52, success: false
Trained epochs: 10000, total average error: 5234.3496, total average loss: 5234.3496
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZTanH, output activator: nl.zeesoft.zdk.functions.ZReLU, learning rate: 0.0928
Initial test results;
  Input: [0.00|0.00], output: [0.36], expectation: [0.00], error: -0.36, loss: 0.35816363
  Input: [1.00|1.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [0.00|1.00], output: [0.00], expectation: [1.00], error: 1.00, loss: 1.0
  Input: [1.00|0.00], output: [0.04], expectation: [1.00], error: 0.96, loss: 0.9644649
  Average error: 0.58, average loss: 0.58, success: false

00100 ----------------------/ 92%
00200 --------------------/ 85%
00300 --------------------| 85%
00400 --------------------\ 87%
00500 ---------------------\ 90%
00600 -----------------------\ 96%
00700 ---------------------/ 89%
00800 -----------------------\ 96%
00900 --------------------/ 86%
01000 -----------------------\ 97%
01100 ---------------------/ 89%
01200 ----------------------\ 92%
01300 ---------------------/ 91%
01400 ------------------------\ 100%
01500 -----------------------/ 97%
01600 -----------------------| 97%
01700 -----------------------\ 98%
01800 -----------------------/ 97%
01900 ------------------------\ 100%
02000 -----------------------/ 97%
02100 -----------------------\ 98%
02200 ----------------------/ 92%
02300 -----------------------\ 97%
02400 -----------------------\ 98%
02500 -----------------------/ 97%
02600 -----------------------\ 99%
02700 --------------------/ 86%
02800 ---------------------\ 91%
02900 -----------------------\ 98%
03000 -----------------------\ 99%
03100 ------------------------\ 100%
03200 ----------------------/ 94%
03300 -----------------------\ 97%
03400 -----------------------| 97%
03500 -----------------------| 97%
03600 -----------------------| 97%
03700 -----------------------\ 98%
03800 -----------------------/ 97%
03900 ---------------------/ 90%
04000 -----------------------\ 97%
04100 ---------------------/ 89%
04200 -----------------------\ 97%
04300 ----------------------/ 94%
04400 ----------------------/ 92%
04500 -----------------------\ 99%
04600 ----------------------/ 94%
04700 ----------------------| 94%
04800 ---------------------/ 91%
04900 -----------------------\ 96%
05000 -----------------------\ 99%
05100 ------------------------\ 100%
05200 -----------------------/ 97%
05300 -----------------------/ 96%
05400 -----------------------\ 98%
05500 -----------------------| 98%
05600 -----------------------/ 97%
05700 -----------------------\ 98%
05800 ---------------------/ 88%
05900 -----------------------\ 97%
06000 ------------------------\ 100%
06100 ------------------------| 100%
06200 ----------------------/ 95%
06300 -----------------------\ 97%
06400 -----------------------\ 98%
06500 -----------------------/ 96%
06600 -----------------------\ 98%
06700 -----------------------\ 99%
06800 -----------------------| 99%
06900 ------------------------\ 101%
07000 -----------------------/ 97%
07100 -----------------------\ 98%
07200 ------------------------\ 100%
07300 -----------------------/ 97%
07400 ------------------------\ 101%
07500 ----------------------/ 92%
07600 ----------------------\ 95%
07700 ---------------------/ 90%
07800 -----------------------\ 98%
07900 -----------------------/ 97%
08000 ----------------------/ 92%
08100 -----------------------\ 98%
08200 -----------------------| 98%
08300 ------------------------\ 101%
08400 -----------------------/ 99%
08500 ------------------------\ 100%
08600 -----------------------/ 99%
08700 ---------------------/ 91%
08800 -----------------------\ 98%
08900 -----------------------/ 96%
09000 -----------------------\ 98%
09100 -----------------------| 98%
09200 -----------------------/ 97%
09300 -----------------------| 97%
09400 -----------------------| 97%
09500 --------------------/ 87%
09600 -----------------------\ 99%
09700 -----------------------/ 98%
09800 -----------------------/ 97%
09900 -----------------------\ 98%
10000 -----------------------| 98%

Latest test results;
  Input: [1.00|1.00], output: [0.51], expectation: [0.00], error: -0.51, loss: 0.50697565
  Input: [0.00|1.00], output: [0.37], expectation: [1.00], error: 0.63, loss: 0.6341663
  Input: [0.00|0.00], output: [0.54], expectation: [0.00], error: -0.54, loss: 0.54238564
  Input: [1.00|0.00], output: [0.39], expectation: [1.00], error: 0.61, loss: 0.6086145
  Average error: 0.57, average loss: 0.57, success: false
Trained epochs: 10000, total average error: 5571.7837, total average loss: 5571.7837
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZReLU, output activator: nl.zeesoft.zdk.functions.ZTanH, learning rate: 0.1684
Initial test results;
  Input: [0.00|0.00], output: [0.18], expectation: [0.00], error: -0.18, loss: 0.18025738
  Input: [1.00|1.00], output: [0.22], expectation: [0.00], error: -0.22, loss: 0.22360091
  Input: [0.00|1.00], output: [0.20], expectation: [1.00], error: 0.80, loss: 0.8046879
  Input: [1.00|0.00], output: [0.21], expectation: [1.00], error: 0.79, loss: 0.7912749
  Average error: 0.50, average loss: 0.50, success: false

00100 -------------------------------------------------\ 201%
00200 -------------------------------------------------/ 200%
00300 ------------------------/ 100%
00400 ------------------------| 100%
00500 -------------------------------------------------\ 200%
00600 -------------------------------------------------| 200%
00700 ------------------------/ 100%
00800 -------------------------------------------------\ 200%
00900 -------------------------------------------------| 200%
01000 -------------------------------------------------| 200%
01100 -------------------------------------------------| 200%
01200 -------------------------/ 104%
01300 ----------------------------------------\ 164%
01400 --------------------------------/ 132%
01500 --------------------------------\ 133%
01600 ------------------------/ 102%
01700 ------------------------| 102%
01800 ------------------------/ 100%
01900 ---------------/ 66%
02000 ------------------------\ 102%
02100 ------------------------| 102%
02200 ------------------------| 102%
02300 ----------------------------------\ 143%
02400 ------------------------/ 100%
02500 ------------------------| 100%
02600 ------------------------------------------\ 172%
02700 -------------------------------------------\ 176%
02800 ------------------------/ 100%
02900 --------------------------------------\ 158%
03000 -------------------/ 80%
03100 ----------------------------------------\ 164%
03200 ------------------------/ 100%
03300 ------------------------| 100%
03400 ---------------------------------------------\ 185%
03500 ------------------------------------------/ 172%
03600 ---------------------------------------------\ 186%
03700 ---------------------------------------------\ 187%
03800 ------------------------/ 100%
03900 ------------------------| 100%
04000 ----------------------------------------------\ 189%
04100 ------------------------/ 100%
04200 ------------------------| 100%
04300 ------------------------| 100%
04400 ------------------------| 100%
04500 ----------------------/ 92%
04600 ----------------------| 92%
04700 ------------------------\ 100%
04800 -----------------------------------------------\ 193%
04900 ---------------------------------------------/ 187%
05000 ----------------------/ 93%
05100 ------------------------\ 100%
05200 -----------------------------------------------\ 194%
05300 -----------------------------------------------\ 195%
05400 ----------------------/ 94%
05500 -----------------------------------------------\ 195%
05600 ----------------------/ 95%
05700 -----------------------------------------------\ 195%
05800 -----------------------------------------------| 195%
05900 -----------------------------------------------| 195%
06000 ------------------------------------------------\ 196%
06100 ------------------------------------------------| 196%
06200 ------------------------------------------------| 196%
06300 ------------------------------------------------| 196%
06400 ------------------------------------------------| 196%
06500 ------------------------------------------------| 196%
06600 ------------------------------------------------| 196%
06700 -----------------------/ 97%
06800 ------------------------\ 100%
06900 ------------------------------------------------\ 197%
07000 ------------------------------------------------| 197%
07100 -----------------------/ 97%
07200 ------------------------------------------------\ 197%
07300 ------------------------------------------------| 197%
07400 -----------------------/ 97%
07500 ------------------------------------------------\ 197%
07600 ------------------------------------------------| 197%
07700 ------------------------------------------------| 197%
07800 ------------------------------------------------| 197%
07900 -----------------------------------------------/ 195%
08000 ------------------------------------------------\ 197%
08100 ------------------------------------------------| 197%
08200 ------------------------------------------------| 197%
08300 ------------------------------------------------\ 198%
08400 -----------------------/ 98%
08500 ------------------------------------------------\ 198%
08600 ------------------------------------------------| 198%
08700 -----------------------/ 98%
08800 -----------------------| 98%
08900 ------------------------\ 100%
09000 ------------------------------------------------\ 198%
09100 -----------------------/ 98%
09200 ------------------------------------------------\ 198%
09300 ------------------------------------------------| 198%
09400 ------------------------/ 100%
09500 ------------------------------------------------\ 198%
09600 ------------------------------------------------| 198%
09700 ------------------------------------------------| 198%
09800 ------------------------/ 100%
09900 ------------------------| 100%
10000 -----------------------/ 98%

Latest test results;
  Input: [0.00|0.00], output: [-0.97], expectation: [0.00], error: 0.97, loss: 0.973257
  Input: [1.00|0.00], output: [1.00], expectation: [1.00], error: 0.00, loss: 0.0
  Input: [0.00|1.00], output: [1.00], expectation: [1.00], error: 0.00, loss: 0.0
  Input: [1.00|1.00], output: [1.00], expectation: [0.00], error: -1.00, loss: 1.0
  Average error: 0.49, average loss: 0.49, success: false
Trained epochs: 10000, total average error: 7495.1743, total average loss: 7495.1743
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZTanH, output activator: nl.zeesoft.zdk.functions.ZTanH, learning rate: 0.1894
Initial test results;
  Input: [0.00|0.00], output: [0.08], expectation: [0.00], error: -0.08, loss: 0.0785081
  Input: [1.00|1.00], output: [0.31], expectation: [0.00], error: -0.31, loss: 0.30611873
  Input: [0.00|1.00], output: [0.14], expectation: [1.00], error: 0.86, loss: 0.85584426
  Input: [1.00|0.00], output: [0.28], expectation: [1.00], error: 0.72, loss: 0.72338545
  Average error: 0.49, average loss: 0.49, success: false

00100 ------------------------\ 101%
00200 --------------------------\ 111%
00300 --------------------------/ 110%
00400 -------------------------/ 107%
00500 ------------------------/ 100%
00600 --------------------------\ 108%
00700 ------------------------/ 101%
00800 ------------------------/ 100%
00900 --------------------------\ 109%
01000 -------------------------/ 107%
01100 ------------------------/ 102%
01200 -------------------------\ 106%
01300 ------------------------/ 103%
01400 --------------------------\ 109%
01500 -------------------------/ 107%
01600 -------------------------/ 104%
01700 ------------------------/ 100%
01800 --------------------------\ 109%
01900 -------------------------/ 106%
02000 -------------------------\ 107%
02100 -------------------------/ 104%
02200 ------------------------/ 101%
02300 ------------------------| 101%
02400 -------------------------\ 107%
02500 -------------------------| 107%
02600 ------------------------/ 101%
02700 -----------------------/ 98%
02800 ------------------------\ 101%
02900 -----------------------/ 98%
03000 --------------------------\ 108%
03100 -------------------------/ 106%
03200 -------------------------| 106%
03300 --------------------------\ 108%
03400 ----------------------/ 93%
03500 --------------------------\ 109%
03600 ---------------------/ 91%
03700 --------------------------\ 108%
03800 --------------------------\ 109%
03900 ---------------------/ 91%
04000 --------------------------\ 109%
04100 ------------------------/ 100%
04200 --------------------------\ 108%
04300 -------------------------/ 104%
04400 --------------------------\ 109%
04500 -----------------------/ 99%
04600 -------------------------\ 107%
04700 --------------------------\ 109%
04800 -------------------------/ 106%
04900 --------------------------\ 108%
05000 -------------------------/ 106%
05100 -------------------------/ 105%
05200 -------------------------/ 104%
05300 --------------------------\ 108%
05400 --------------------------\ 110%
05500 -------------------------/ 107%
05600 ------------------------/ 102%
05700 -------------------------\ 107%
05800 -------------------------| 107%
05900 --------------------------\ 108%
06000 -----------------------/ 99%
06100 --------------------------\ 108%
06200 -----------------------/ 96%
06300 ------------------------\ 101%
06400 ----------------------/ 94%
06500 --------------------------\ 109%
06600 -------------------------/ 105%
06700 ----------------------/ 95%
06800 --------------------------\ 108%
06900 -----------------------/ 98%
07000 ------------------------\ 102%
07100 ----------------------/ 92%
07200 ------------------------\ 103%
07300 --------------------------\ 109%
07400 --------------------------/ 108%
07500 --------------------------| 108%
07600 ------------------------/ 101%
07700 ------------------------\ 103%
07800 ------------------------/ 101%
07900 -------------------------\ 105%
08000 ----------------------/ 92%
08100 --------------------------\ 110%
08200 -----------------------/ 97%
08300 --------------------------\ 109%
08400 --------------------------| 109%
08500 ------------------------/ 100%
08600 -------------------------\ 106%
08700 -----------------------/ 98%
08800 ----------------------/ 93%
08900 ----------------------| 93%
09000 ----------------------\ 94%
09100 --------------------------\ 108%
09200 --------------------------\ 109%
09300 ------------------------/ 102%
09400 ----------------------/ 95%
09500 --------------------------\ 109%
09600 ------------------------/ 100%
09700 --------------------------\ 108%
09800 --------------------------| 108%
09900 ------------------------/ 101%
10000 --------------------------\ 111%

Latest test results;
  Input: [1.00|1.00], output: [0.66], expectation: [0.00], error: -0.66, loss: 0.65642506
  Input: [0.00|1.00], output: [0.36], expectation: [1.00], error: 0.64, loss: 0.64257777
  Input: [1.00|0.00], output: [0.57], expectation: [1.00], error: 0.43, loss: 0.4301445
  Input: [0.00|0.00], output: [0.46], expectation: [0.00], error: -0.46, loss: 0.46426213
  Average error: 0.55, average loss: 0.55, success: false
Trained epochs: 10000, total average error: 5129.597, total average loss: 5129.597
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZTanH, output activator: nl.zeesoft.zdk.functions.ZReLU, learning rate: 0.179
Initial test results;
  Input: [0.00|0.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [1.00|1.00], output: [0.00], expectation: [0.00], error: 0.00, loss: 0.0
  Input: [0.00|1.00], output: [0.00], expectation: [1.00], error: 1.00, loss: 1.0
  Input: [1.00|0.00], output: [0.00], expectation: [1.00], error: 1.00, loss: 1.0
  Average error: 0.50, average loss: 0.50, success: false

00100 ----------------------------\ 117%
00200 -----------------------------\ 121%
00300 -----------------------------/ 120%
00400 ------------------------------\ 126%
00500 ---------------------------------\ 136%
00600 ------------------------------/ 126%
00700 ------------------------------| 126%
00800 ---------------------------/ 112%
00900 -------------------/ 83%
01000 ------------------------------\ 127%
01100 -------------------------------\ 129%
01200 ------------------------------/ 126%
01300 ----------------------------------\ 141%
01400 ------------------------------/ 127%
01500 -------------------------------\ 129%
01600 ---------------------------------\ 136%
01700 ------------------------------/ 126%
01800 ----------------------------------\ 141%
01900 ------------------------------/ 126%
02000 ------------------------------/ 125%
02100 -----------------------------/ 120%
02200 ----------------------------------\ 141%
02300 ------------------------------/ 127%
02400 -------------------------------\ 129%
02500 ----------------------------------\ 140%
02600 ------------------------------/ 126%
02700 ------------------------------/ 125%
02800 ----------------------------------\ 141%
02900 ------------------------------/ 126%
03000 -----------------------------/ 120%
03100 ----------------------------/ 119%
03200 -------------------------------\ 129%
03300 ----------------------------/ 119%
03400 ----------------------/ 92%
03500 -------------------------------\ 129%
03600 -------------------------------| 129%
03700 ----------------------/ 95%
03800 -----------------------------\ 120%
03900 ----------------------------/ 119%
04000 -----------------------------\ 120%
04100 -----------------------------| 120%
04200 ----------------------/ 95%
04300 ----------------------------\ 116%
04400 ---------------------------------\ 136%
04500 ---------------------------/ 112%
04600 ------------------------------\ 125%
04700 ---------------------------/ 112%
04800 -------------------------------\ 129%
04900 ----------------------------/ 116%
05000 ------------------------------\ 126%
05100 ----------------------/ 95%
05200 ----------------------------\ 119%
05300 --------------------------/ 108%
05400 -------------------------------\ 129%
05500 ----------------------------/ 119%
05600 --------------------------------\ 135%
05700 ------------------------------/ 127%
05800 ----------------------------/ 116%
05900 ------------------------------\ 125%
06000 ----------------------/ 92%
06100 ------------------------------\ 126%
06200 ----------------------------------\ 140%
06300 ------------------------------/ 126%
06400 ----------------------------/ 116%
06500 -------------------------------\ 129%
06600 -------------------------------| 129%
06700 ---------------------/ 91%
06800 ---------------------------\ 112%
06900 ---------------------------------\ 136%
07000 --------------------------/ 111%
07100 -------------------------/ 107%
07200 ---------------------------\ 112%
07300 ----------------------/ 94%
07400 ------------------------------\ 126%
07500 --------------------------------\ 134%
07600 --------------------------------| 134%
07700 --------------------------/ 111%
07800 -----------------------------\ 120%
07900 -------------------------------\ 129%
08000 -----------------------------/ 120%
08100 ----------------------------/ 119%
08200 ---------------------------------\ 136%
08300 ------------------------------/ 127%
08400 ------------------------------/ 124%
08500 -------------------------/ 107%
08600 ------------------------------\ 126%
08700 ----------------------/ 95%
08800 ------------------------------\ 126%
08900 --------------------------/ 109%
09000 ------------------------------\ 126%
09100 --------------------------------\ 134%
09200 ----------------------------/ 119%
09300 ------------------------------\ 126%
09400 ----------------------------/ 119%
09500 -----------------------------\ 120%
09600 ----------------------------------\ 141%
09700 ----------------------------------/ 140%
09800 -------------------------------/ 129%
09900 ----------------------/ 95%
10000 ------------------------------\ 125%

Latest test results;
  Input: [1.00|1.00], output: [0.33], expectation: [0.00], error: -0.33, loss: 0.33049858
  Input: [0.00|1.00], output: [0.15], expectation: [1.00], error: 0.85, loss: 0.84697926
  Input: [0.00|0.00], output: [0.61], expectation: [0.00], error: -0.61, loss: 0.60784864
  Input: [1.00|0.00], output: [0.28], expectation: [1.00], error: 0.72, loss: 0.7185662
  Average error: 0.63, average loss: 0.63, success: false
Trained epochs: 10000, total average error: 5997.9946, total average loss: 5997.9946
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZTanH, output activator: nl.zeesoft.zdk.functions.ZLeakyReLU, learning rate: 0.0696
Initial test results;
  Input: [0.00|0.00], output: [-0.00], expectation: [0.00], error: 0.00, loss: 8.0401596E-4
  Input: [1.00|1.00], output: [0.29], expectation: [0.00], error: -0.29, loss: 0.2910824
  Input: [0.00|1.00], output: [0.03], expectation: [1.00], error: 0.97, loss: 0.96509385
  Input: [1.00|0.00], output: [0.24], expectation: [1.00], error: 0.76, loss: 0.763043
  Average error: 0.51, average loss: 0.51, success: false

00100 -----------------------/ 98%
00200 ----------------------/ 92%
00300 ---------------------/ 90%
00400 ----------------------\ 94%
00500 ---------------------/ 89%
00600 -----------------/ 75%
00700 ------------------\ 76%
00800 --------------------\ 84%
00900 --------------------\ 86%
01000 ----------------/ 69%
01100 --------------------\ 86%
01200 --------------------/ 85%
01300 ------------------/ 78%
01400 -----------------------\ 99%
01500 ----------------/ 69%
01600 ---------------------\ 89%
01700 ---------------/ 64%
01800 ------------------------\ 101%
01900 ----------------/ 70%
02000 ------------------------\ 103%
02100 ---------------------------\ 113%
02200 -------------------/ 81%
02300 -------------------| 81%
02400 --------------------\ 87%
02500 --------------------------\ 109%
02600 -----------------------/ 98%
02700 ---------------------/ 90%
02800 ----------------------\ 95%
02900 ----------------------/ 94%
03000 -----------------------\ 99%
03100 --------------------------\ 108%
03200 ------------------------/ 101%
03300 -----------------------/ 99%
03400 -------------------------\ 104%
03500 ------------------------/ 101%
03600 --------------------------\ 109%
03700 --------------------------\ 110%
03800 --------------------------/ 109%
03900 --------------------------\ 110%
04000 --------------------------/ 109%
04100 --------------------------/ 108%
04200 --------------------------\ 109%
04300 --------------------------/ 108%
04400 --------------------------| 108%
04500 -------------------------/ 107%
04600 -------------------------/ 106%
04700 --------------------------\ 108%
04800 --------------------------| 108%
04900 ------------------------/ 101%
05000 --------------------------\ 108%
05100 --------------------------| 108%
05200 --------------------------| 108%
05300 -------------------------/ 105%
05400 --------------------------\ 108%
05500 --------------------------\ 109%
05600 -------------------------/ 104%
05700 ------------------------/ 102%
05800 --------------------------\ 108%
05900 --------------------------| 108%
06000 --------------------------| 108%
06100 --------------------------\ 110%
06200 -------------------------/ 105%
06300 --------------------------\ 108%
06400 -------------------------/ 105%
06500 -------------------------| 105%
06600 -------------------------\ 106%
06700 -------------------------/ 105%
06800 --------------------------\ 109%
06900 --------------------------/ 108%
07000 --------------------------\ 109%
07100 --------------------------| 109%
07200 --------------------------\ 110%
07300 --------------------------/ 109%
07400 --------------------------\ 110%
07500 --------------------------/ 108%
07600 -------------------------/ 105%
07700 --------------------------\ 109%
07800 --------------------------| 109%
07900 --------------------------| 109%
08000 ------------------------/ 102%
08100 --------------------------\ 108%
08200 --------------------------\ 109%
08300 --------------------------/ 108%
08400 -------------------------/ 105%
08500 --------------------------\ 108%
08600 -------------------------/ 105%
08700 --------------------------\ 108%
08800 --------------------------| 108%
08900 --------------------------\ 109%
09000 ------------------------/ 102%
09100 --------------------------\ 109%
09200 --------------------------\ 111%
09300 --------------------------/ 109%
09400 --------------------------| 109%
09500 --------------------------/ 108%
09600 --------------------------\ 109%
09700 --------------------------| 109%
09800 --------------------------| 109%
09900 --------------------------| 109%
10000 -------------------------/ 105%

Latest test results;
  Input: [1.00|1.00], output: [0.52], expectation: [0.00], error: -0.52, loss: 0.5174825
  Input: [0.00|0.00], output: [0.41], expectation: [0.00], error: -0.41, loss: 0.4094321
  Input: [0.00|1.00], output: [0.32], expectation: [1.00], error: 0.68, loss: 0.67605716
  Input: [1.00|0.00], output: [0.47], expectation: [1.00], error: 0.53, loss: 0.5348964
  Average error: 0.53, average loss: 0.53, success: false
Trained epochs: 10000, total average error: 5127.9326, total average loss: 5127.9326
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZTanH, output activator: nl.zeesoft.zdk.functions.ZLeakyReLU, learning rate: 0.133
Initial test results;
  Input: [0.00|0.00], output: [-0.01], expectation: [0.00], error: 0.01, loss: 0.012229073
  Input: [1.00|1.00], output: [-0.01], expectation: [0.00], error: 0.01, loss: 0.006076091
  Input: [0.00|1.00], output: [-0.01], expectation: [1.00], error: 1.01, loss: 1.0107452
  Input: [1.00|0.00], output: [-0.01], expectation: [1.00], error: 1.01, loss: 1.0057288
  Average error: 0.51, average loss: 0.51, success: false

00100 --------------------------\ 109%
00200 -----------------------/ 98%
00300 ---------------------------\ 112%
00400 ---------------------------| 112%
00500 ----------------------------\ 117%
00600 ---------------------------/ 114%
00700 ------------------------------\ 124%
00800 -----------------------------/ 122%
00900 ----------------------/ 92%
01000 ---------------------------\ 114%
01100 ----------------------------\ 119%
01200 ---------------------------/ 113%
01300 ----------------------/ 92%
01400 ------------------------------\ 124%
01500 ---------------------------/ 113%
01600 ---------------------------| 113%
01700 ---------------------------\ 114%
01800 ----------------------------\ 117%
01900 ----------------------------\ 119%
02000 ------------------------/ 102%
02100 ----------------------------\ 117%
02200 -----------------------------\ 120%
02300 --------------------------/ 109%
02400 ---------------------------\ 113%
02500 ----------------------/ 94%
02600 ----------------------------\ 117%
02700 ---------------------------/ 114%
02800 ----------------------------\ 118%
02900 --------------------------/ 110%
03000 ----------------------------\ 118%
03100 ----------------------------/ 116%
03200 ----------------------------\ 119%
03300 ---------------------------/ 115%
03400 ----------------------------\ 119%
03500 -------------------------/ 107%
03600 ---------------------------\ 114%
03700 ----------------------------\ 116%
03800 ----------------------------| 116%
03900 -----------------------------\ 121%
04000 ---------------------------/ 114%
04100 ----------------------------\ 119%
04200 ----------------------------/ 118%
04300 ----------------------------/ 116%
04400 -----------------------------\ 123%
04500 -----------------------------/ 120%
04600 ---------------------------/ 113%
04700 ----------------------------\ 118%
04800 ----------------------------| 118%
04900 ---------------------------/ 113%
05000 ---------------------------| 113%
05100 -----------------------------\ 122%
05200 ---------------------------/ 114%
05300 ---------------------------/ 113%
05400 ----------------------/ 94%
05500 ---------------------------\ 115%
05600 -----------------------------\ 122%
05700 ---------------------------/ 114%
05800 --------------------------/ 108%
05900 ---------------------------\ 115%
06000 --------------------------/ 109%
06100 --------------------------| 109%
06200 ---------------------------\ 114%
06300 --------------------------/ 110%
06400 ----------------------------\ 117%
06500 ----------------------------| 117%
06600 -------------------------/ 105%
06700 ----------------------------\ 117%
06800 ----------------------------/ 116%
06900 -------------------------/ 106%
07000 ----------------------------\ 117%
07100 --------------------------/ 109%
07200 ----------------------------\ 118%
07300 -------------------------/ 105%
07400 ---------------------------\ 113%
07500 ----------------------------\ 119%
07600 ---------------------------/ 115%
07700 ------------------------------\ 124%
07800 -----------------------------/ 120%
07900 ------------------------/ 101%
08000 ---------------------------\ 114%
08100 ---------------------------/ 113%
08200 ----------------------------\ 116%
08300 ----------------------/ 92%
08400 ------------------------\ 102%
08500 ------------------------------\ 125%
08600 -----------------------------/ 122%
08700 ----------------------------/ 117%
08800 -----------------------------\ 123%
08900 ----------------------------/ 118%
09000 -------------------------/ 105%
09100 ---------------------------\ 113%
09200 --------------------------/ 110%
09300 ---------------------------\ 114%
09400 ------------------------/ 100%
09500 ---------------------------\ 114%
09600 ----------------------------\ 118%
09700 ----------------------/ 92%
09800 ---------------------------\ 114%
09900 ----------------------------\ 117%
10000 -----------------------------\ 123%

Latest test results;
  Input: [1.00|1.00], output: [0.64], expectation: [0.00], error: -0.64, loss: 0.6357168
  Input: [0.00|1.00], output: [0.38], expectation: [1.00], error: 0.62, loss: 0.6179342
  Input: [0.00|0.00], output: [0.63], expectation: [0.00], error: -0.63, loss: 0.6286216
  Input: [1.00|0.00], output: [0.38], expectation: [1.00], error: 0.62, loss: 0.6221986
  Average error: 0.63, average loss: 0.63, success: false
Trained epochs: 10000, total average error: 5791.024, total average loss: 5791.024
================================================================================
Neural net activator: nl.zeesoft.zdk.functions.ZSigmoid, output activator: nl.zeesoft.zdk.functions.ZLeakyReLU, learning rate: 0.0974
Initial test results;
  Input: [0.00|0.00], output: [0.75], expectation: [0.00], error: -0.75, loss: 0.745
  Input: [1.00|1.00], output: [0.77], expectation: [0.00], error: -0.77, loss: 0.76826537
  Input: [0.00|1.00], output: [0.76], expectation: [1.00], error: 0.24, loss: 0.23674023
  Input: [1.00|0.00], output: [0.75], expectation: [1.00], error: 0.25, loss: 0.249708
  Average error: 0.50, average loss: 0.50, success: false

00100 -------------------------\ 104%
00200 --------------------------\ 109%
00300 --------------------------\ 110%
00400 --------------------------| 110%
00500 --------------------------/ 108%
00600 -------------------------/ 106%
00700 --------------------------\ 111%
00800 -------------------------/ 105%
00900 -------------------------\ 106%
01000 -------------------------| 106%
01100 ----------------------/ 93%
01200 ---------------------/ 88%
01300 --------------------/ 87%
01400 -------------------/ 83%
01500 ----------------/ 70%
01600 ----------------| 70%
01700 -----------------\ 75%
01800 -----------------/ 73%
01900 ---------------/ 64%
02000 --------------/ 63%
02100 --------------/ 61%
02200 --------------\ 63%
02300 ---------------\ 67%
02400 --------------/ 63%
02500 --------------/ 60%
02600 -------------/ 57%
02700 --------------\ 63%
02800 --------------/ 61%
02900 -------------/ 58%
03000 ------------/ 53%
03100 ------/ 29%

Latest test results;
  Input: [0.00|0.00], output: [0.02], expectation: [0.00], error: -0.02, loss: 0.016393125
  Input: [1.00|0.00], output: [0.93], expectation: [1.00], error: 0.07, loss: 0.07177585
  Input: [1.00|1.00], output: [0.10], expectation: [0.00], error: -0.10, loss: 0.09851229
  Input: [0.00|1.00], output: [0.92], expectation: [1.00], error: 0.08, loss: 0.079591095
  Average error: 0.07, average loss: 0.07, success: true
Trained epochs: 3174, total average error: 1269.6514, total average loss: 1269.6514
~~~~

nl.zeesoft.zdk.test.impl.TestEvolver
------------------------------------
This test shows how to use an *Evolver* and a *TestSet* to generate, train and select the best *GeneticNN* for a certain task.  
Evolvers use multi threading to use processing power effectively.  
When specifying multiple evolvers, half of them are used to generate completely new neural nets.  
The other half are used to generate mutations of the best-so-far generated neural net.  

**Example implementation**  
~~~~
// Create the TestSet
TestSet tSet = new TestSet(inputs,outputs);
// (Add tests to the test ...)
// Create the Evolver
Evolver evolver = new Evolver(new Messenger(),new WorkerUnion(),maxHiddenLayers,maxHiddenNeurons,codePropertyStart,tSet,evolvers);
// Start the evolver
evolver.start();
// (Give it some time ...)
// Stop the evolver
evolver.stop();
// Get the best-so-far result
EvolverUnit unit = evolver.getBestSoFar();
~~~~

Class references;  
 * [TestEvolver](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestEvolver.java)
 * [Evolver](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/genetic/Evolver.java)
 * [TestSet](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/neural/TestSet.java)
 * [GeneticNN](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/genetic/GeneticNN.java)

**Test output**  
The output of this test shows the evolver debug output and the evolver object converted to JSON.  
~~~~
2019-12-23 19:21:37:167 DBG nl.zeesoft.zdk.genetic.Evolver: Started
2019-12-23 19:21:37:204 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 6078519291379360
- Size: 14
- Initial average loss: 0.25000 (final: 0.00000)
- Total average loss: 27.00000 (epochs: 43)
- Training result: 6.75000
2019-12-23 19:21:37:323 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 6078519291379360
- Size: 14
- Initial average loss: 0.25000 (final: 0.00000)
- Total average loss: 13.50000 (epochs: 22)
- Training result: 3.37500
2019-12-23 19:21:37:931 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 6078619291379360
- Size: 14
- Initial average loss: 0.25000 (final: 0.00000)
- Total average loss: 9.75000 (epochs: 20)
- Training result: 2.43750
2019-12-23 19:21:39:926 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 6078619191379360
- Size: 14
- Initial average loss: 0.25000 (final: 0.00000)
- Total average loss: 8.50000 (epochs: 21)
- Training result: 2.12500
2019-12-23 19:21:40:026 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 6073619191379360
- Size: 14
- Initial average loss: 0.25000 (final: 0.00000)
- Total average loss: 6.75000 (epochs: 16)
- Training result: 1.68750
2019-12-23 19:21:40:233 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 8361131216801774
- Size: 14
- Initial average loss: 0.24487 (final: 0.06787)
- Total average loss: 2.03328 (epochs: 13)
- Training result: 0.49788
2019-12-23 19:21:40:375 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 8361131216801774
- Size: 14
- Initial average loss: 0.25000 (final: 0.00000)
- Total average loss: 0.25000 (epochs: 2)
- Training result: 0.06250
2019-12-23 19:21:41:318 DBG nl.zeesoft.zdk.genetic.Evolver: Selected new best genetic neural net;
- Code: 8361132216801774
- Size: 14
- Initial average loss: 0.00000 (final: 0.00000)
- Total average loss: 0.00000 (epochs: 0)
- Training result: 0.00000

Evolver JSON;
{
  "mutationRate": 0.05,
  "trainEpochBatches": 1000,
  "trainEpochBatchSize": 10,
  "checkFactorQuarter": 0.75,
  "checkFactorHalf": 0.5,
  "sleepMs": 10,
  "sleepMsFoundBest": 10,
  "maxLogLines": 20,
  "log": [
    "2019-12-23 19:21:37:204 SEL code: 6078519291379360, size: 14, initial loss: 0.25000 (final: 0.00000), total loss: 27.00000, result: 6.75000 (epochs: 43)",
    "2019-12-23 19:21:37:323 SEL code: 6078519291379360, size: 14, initial loss: 0.25000 (final: 0.00000), total loss: 13.50000, result: 3.37500 (epochs: 22)",
    "2019-12-23 19:21:37:931 SEL code: 6078619291379360, size: 14, initial loss: 0.25000 (final: 0.00000), total loss: 9.75000, result: 2.43750 (epochs: 20)",
    "2019-12-23 19:21:39:926 SEL code: 6078619191379360, size: 14, initial loss: 0.25000 (final: 0.00000), total loss: 8.50000, result: 2.12500 (epochs: 21)",
    "2019-12-23 19:21:40:026 SEL code: 6073619191379360, size: 14, initial loss: 0.25000 (final: 0.00000), total loss: 6.75000, result: 1.68750 (epochs: 16)",
    "2019-12-23 19:21:40:233 SEL code: 8361131216801774, size: 14, initial loss: 0.24487 (final: 0.06787), total loss: 2.03328, result: 0.49788 (epochs: 13)",
    "2019-12-23 19:21:40:375 SEL code: 8361131216801774, size: 14, initial loss: 0.25000 (final: 0.00000), total loss: 0.25000, result: 0.06250 (epochs: 2)",
    "2019-12-23 19:21:41:318 SEL code: 8361132216801774, size: 14, initial loss: 0.00000 (final: 0.00000), total loss: 0.00000, result: 0.00000 (epochs: 0)"
  ],
  "bestSoFar": [
    {
      "geneticNN": [
        {
          "inputNeurons": 2,
          "maxHiddenLayers": 1,
          "maxHiddenNeurons": 2,
          "outputNeurons": 1,
          "codePropertyStart": 0,
          "code": "uMmB1D5KlC3GcODNwG3JGAzMTFZB8A1GCMIKMOOHiAlDaE3MMPoKQBuLYIaAwFaITCjH2",
          "neuralNet": [
            {
              "inputNeurons": 2,
              "hiddenLayers": 1,
              "hiddenNeurons": 2,
              "outputNeurons": 1,
              "weightFunction": "nl.zeesoft.zdk.functions.ZWeightKaiming",
              "biasFunction": "nl.zeesoft.zdk.functions.ZWeightZero",
              "activator": "nl.zeesoft.zdk.functions.ZLeakyReLU",
              "outputActivator": "nl.zeesoft.zdk.functions.ZSoftmaxTop",
              "learningRate": 0.136,
              "values": [
                "2,1,1.0,1.0",
                "2,1,-0.001959591,-0.0023678406",
                "1,1,0.0"
              ],
              "weights": [
                "1,1,0.0",
                "2,2,0.5486858,-0.7446449,-0.6842242,0.44744012",
                "1,2,0.58951056,0.6433993"
              ],
              "biases": [
                "1,1,0.0",
                "2,1,0.0,0.0",
                "1,1,0.0"
              ]
            }
          ]
        }
      ],
      "trainingProgram": [
        {
          "stopOnSuccess": true,
          "trainedEpochs": 0,
          "totalAverageError": 0.0,
          "totalAverageLoss": 0.0,
          "initialResults": [
            {
              "inputNeurons": 2,
              "outputNeurons": 1,
              "lossFunction": "nl.zeesoft.zdk.functions.ZMeanAbsoluteError",
              "errorTolerance": 0.1,
              "averageError": 0.0,
              "averageLoss": 0.0,
              "success": true,
              "tests": [
                {
                  "inputs": "0.0,0.0",
                  "outputs": "0.0",
                  "expectations": "0.0",
                  "errors": "0.0"
                },
                {
                  "inputs": "1.0,0.0",
                  "outputs": "1.0",
                  "expectations": "1.0",
                  "errors": "0.0"
                },
                {
                  "inputs": "0.0,1.0",
                  "outputs": "1.0",
                  "expectations": "1.0",
                  "errors": "0.0"
                },
                {
                  "inputs": "1.0,1.0",
                  "outputs": "0.0",
                  "expectations": "0.0",
                  "errors": "0.0"
                }
              ]
            }
          ],
          "latestResults": [
            {
              "inputNeurons": 2,
              "outputNeurons": 1,
              "lossFunction": "nl.zeesoft.zdk.functions.ZMeanAbsoluteError",
              "errorTolerance": 0.1,
              "averageError": 0.0,
              "averageLoss": 0.0,
              "success": true,
              "tests": [
                {
                  "inputs": "0.0,0.0",
                  "outputs": "0.0",
                  "expectations": "0.0",
                  "errors": "0.0"
                },
                {
                  "inputs": "1.0,0.0",
                  "outputs": "1.0",
                  "expectations": "1.0",
                  "errors": "0.0"
                },
                {
                  "inputs": "0.0,1.0",
                  "outputs": "1.0",
                  "expectations": "1.0",
                  "errors": "0.0"
                },
                {
                  "inputs": "1.0,1.0",
                  "outputs": "0.0",
                  "expectations": "0.0",
                  "errors": "0.0"
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}
~~~~

nl.zeesoft.zdk.test.impl.htm.TestSDR
------------------------------------
This test shows how to create and compare sparse distributed representations using *SDR* instances.

**Example implementation**  
~~~~
// Create the SDR
SDR sdrA = new SDR(100);
// Turn on the first and last bits
sdrA.setBit(0,true);
sdrA.setBit(99,true);
// Create another SDR
SDR sdrB = new SDR(100);
// Turn on the first and middle bits
sdrB.setBit(0,true);
sdrB.setBit(50,true);
// Check if the SDRs have one overlapping bit
System.out.println(sdrA.matches(sdrB,1));
~~~~

Class references;  
 * [TestSDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestSDR.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows two SDRs and if they match at least one bit.
~~~~
SDR A: 100,0,99
SDR B: 100,0,50
Match: true
~~~~

nl.zeesoft.zdk.test.impl.htm.TestSDRMap
---------------------------------------
This test shows how to use an *SDRMap* to maintain a list of Sparse Distributed Representations.
By default, an *SDRMap* uses an index for each bit of every SDR in the list so it can quickly retrieve matching SDRs.

**Example implementation**  
~~~~
// Create the SDR map
SDRMap sdrMap = new SDRMap(100);
// Create an SDR
SDR sdrA = new SDR(100);
sdrA.randomize(2);
// Create another SDR
SDR sdrB = new SDR(100);
sdrB.randomize(2);
// Add the SDRs to the SDR map
sdrMap.add(sdrA);
sdrMap.add(sdrB);
// Create a third SDR
SDR sdrC = new SDR(100);
sdrC.randomize(2);
// Get matches from the SDR map
SortedMap<Integer,List<SDR>> matchesByOverlapScore = sdrMap.getMatches(sdrC);
~~~~

Class references;  
 * [TestSDRMap](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestSDRMap.java)
 * [SDRMap](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDRMap.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows the SDR map, a third SDR and the number of matches for the that SDR in the set.
~~~~
SDR map: 100,2|51,11|0,75
Number of SDR A matches in SDR map: 1
SDR C: 100,38,92
Number of SDR C matches in SDR map: 0
~~~~

nl.zeesoft.zdk.test.impl.htm.TestScalarEncoder
----------------------------------------------
This test shows how to use a *ScalarEncoder* to convert a range of scalar values into sparse distributed representations.

**Example implementation**  
~~~~
// Create the encoder
ScalarEncoder enc = new ScalarEncoder(52,2,0,50);
// Obtain the SDR for a certain value
SDR sdr = enc.getSDRForValue(0);
~~~~

Class references;  
 * [TestScalarEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestScalarEncoder.java)
 * [ScalarEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/ScalarEncoder.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows two scalar encoders and the SDRs they generate for several values.
~~~~
ScalarEncoder length: 52, bits: 2, resolution: 1.0, min: 0.0, max: 50.0, periodic: false
SDR for value 0:  1100000000000000000000000000000000000000000000000000
SDR for value 1:  0110000000000000000000000000000000000000000000000000
SDR for value 24: 0000000000000000000000001100000000000000000000000000
SDR for value 25: 0000000000000000000000000110000000000000000000000000
SDR for value 26: 0000000000000000000000000011000000000000000000000000
SDR for value 49: 0000000000000000000000000000000000000000000000000110
SDR for value 50: 0000000000000000000000000000000000000000000000000011
SDR for value 51: 0000000000000000000000000000000000000000000000000011

ScalarEncoder length: 50, bits: 2, resolution: 1.0, min: 0.0, max: 50.0, periodic: true
SDR for value 0:  11000000000000000000000000000000000000000000000000
SDR for value 1:  01100000000000000000000000000000000000000000000000
SDR for value 24: 00000000000000000000000011000000000000000000000000
SDR for value 25: 00000000000000000000000001100000000000000000000000
SDR for value 26: 00000000000000000000000000110000000000000000000000
SDR for value 49: 10000000000000000000000000000000000000000000000001
SDR for value 50: 11000000000000000000000000000000000000000000000000
SDR for value 51: 01100000000000000000000000000000000000000000000000
~~~~

nl.zeesoft.zdk.test.impl.htm.TestRDScalarEncoder
------------------------------------------------
This test shows how to use an *RDScalarEncoder* to convert a range of scalar values into sparse distributed representations.

**Example implementation**  
~~~~
// Create the encoder
RDScalarEncoder enc = new RDScalarEncoder(50,4);
// Obtain the SDR for a certain value
SDR sdr = enc.getSDRForValue(0);
~~~~

Class references;  
 * [TestRDScalarEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestRDScalarEncoder.java)
 * [RDScalarEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/RDScalarEncoder.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows a random distributed scalar encoder and the SDRs it generated for several values.
~~~~
RDScalarEncoder length: 50, bits: 4, resolution: 1.0, capacity: 230300
SDR for value 0:  00000000000010000001000010100000000000000000000000
SDR for value 1:  00000000000000000001000010100100000000000000000000
SDR for value 24: 00000000000100001100000000000000000001000000000000
SDR for value 25: 00000000000100001100000000000000000000000001000000
SDR for value 75: 00000000001000000010000000000000100000000100000000
SDR for value 76: 00001000001000000010000000000000000000000100000000
SDR for value -1: 00000000000011000001000000100000000000000000000000
~~~~

nl.zeesoft.zdk.test.impl.htm.TestDateTimeEncoder
------------------------------------------------
This test shows how to use a *DateTimeEncoder* to convert a range of dates/times into combined periodic sparse distributed representations.
The *DateTimeEncoder* is merely an example implementation of a *CombinedEncoder* used to test this library.

**Example implementation**  
~~~~
// Create the encoder
DateTimeEncoder enc = new DateTimeEncoder();
// Obtain the SDR for a certain value
SDR sdr = enc.getSDRForValue(System.currentTimeMillis());
~~~~

Class references;  
 * [TestDateTimeEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestDateTimeEncoder.java)
 * [DateTimeEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/DateTimeEncoder.java)
 * [CombinedEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/CombinedEncoder.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows how the generated SDRs represent several date/times.
~~~~
Changing months;
SDR for 2019-01-01 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000111111110000000000
SDR for 2019-02-01 01:00:00:000; 111111110000000000000000000000000000000000000000000011111111000000000000000000000000000000000000100000000000000001111111
SDR for 2019-03-01 01:00:00:000; 111111110000000000000000000000000000000000000000000000001111111100000000000000000000000000000000100000000000000001111111
SDR for 2019-04-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000111111110000000000000
SDR for 2019-05-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000011111111000000
SDR for 2019-06-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000000000001111111100000000000000000000111100000000000000001111
SDR for 2019-07-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000111111110000000000000
SDR for 2019-08-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000011111111000
SDR for 2019-09-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000000000000000000000001111111100000000111111110000000000000000
SDR for 2019-10-01 02:00:00:000; 111111110000000000000000000000000000000000000000000000000000000000000000000000000000111111110000000000111111110000000000
SDR for 2019-11-01 01:00:00:000; 111111110000000000000000000000000000000000000000000000000000000000000000000000000000000011111111100000000000000001111111
SDR for 2019-12-01 01:00:00:000; 111111110000000000000000000000000000000000000000111100000000000000000000000000000000000000001111111111110000000000000000

Changing days of week;
SDR for 2020-01-01 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000011111111000000
SDR for 2020-01-02 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000011111111000
SDR for 2020-01-03 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000100000000000000001111111
SDR for 2020-01-04 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000111100000000000000001111
SDR for 2020-01-05 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000111111110000000000000000
SDR for 2020-01-06 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000111111110000000000000
SDR for 2020-01-07 01:00:00:000; 111111110000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000111111110000000000

Changing hours of day;
SDR for 2020-01-08 01:00:00:000; 111111110000000000000000000000000000000000000000011111111000000000000000000000000000000000000000000000000011111111000000
SDR for 2020-01-08 02:00:00:000; 001111111100000000000000000000000000000000000000011111111000000000000000000000000000000000000000000000000011111111000000
SDR for 2020-01-08 03:00:00:000; 000011111111000000000000000000000000000000000000011111111000000000000000000000000000000000000000000000000011111111000000
SDR for 2020-01-08 04:00:00:000; 000000111111110000000000000000000000000000000000011111111000000000000000000000000000000000000000000000000011111111000000
SDR for 2020-01-08 05:00:00:000; 000000001111111100000000000000000000000000000000011111111000000000000000000000000000000000000000000000000011111111000000
SDR for 2020-01-08 06:00:00:000; 000000000011111111000000000000000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 07:00:00:000; 000000000000111111110000000000000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 08:00:00:000; 000000000000001111111100000000000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 09:00:00:000; 000000000000000011111111000000000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 10:00:00:000; 000000000000000000111111110000000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 11:00:00:000; 000000000000000000001111111100000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 12:00:00:000; 000000000000000000000011111111000000000000000000011111111000000000000000000000000000000000000000000000000001111111100000
SDR for 2020-01-08 13:00:00:000; 000000000000000000000000111111110000000000000000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 14:00:00:000; 000000000000000000000000001111111100000000000000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 15:00:00:000; 000000000000000000000000000011111111000000000000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 16:00:00:000; 000000000000000000000000000000111111110000000000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 17:00:00:000; 000000000000000000000000000000001111111100000000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 18:00:00:000; 000000000000000000000000000000000011111111000000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 19:00:00:000; 000000000000000000000000000000000000111111110000011111111000000000000000000000000000000000000000000000000000111111110000
SDR for 2020-01-08 20:00:00:000; 000000000000000000000000000000000000001111111100011111111000000000000000000000000000000000000000000000000000011111111000
SDR for 2020-01-08 21:00:00:000; 000000000000000000000000000000000000000011111111011111111000000000000000000000000000000000000000000000000000011111111000
SDR for 2020-01-08 22:00:00:000; 110000000000000000000000000000000000000000111111011111111000000000000000000000000000000000000000000000000000011111111000
SDR for 2020-01-08 23:00:00:000; 111100000000000000000000000000000000000000001111011111111000000000000000000000000000000000000000000000000000011111111000
SDR for 2020-01-09 00:00:00:000; 111111000000000000000000000000000000000000000011011111111000000000000000000000000000000000000000000000000000011111111000
~~~~

nl.zeesoft.zdk.test.impl.htm.TestDateTimeValuesEncoder
------------------------------------------------------
This test shows how to use a *DateTimeValueEncoder* to convert a range of dates/times and values into combined periodic sparse distributed representations.
The *DateTimeValueEncoder* is merely an example implementation of a *CombinedEncoder* used to test this library.
It uses random distributed scalar encoders to represent the values in order to show how these use state to maintain consistent representations.

**Example implementation**  
~~~~
// Create the encoder
DateTimeValueEncoder enc = new DateTimeEncoder();
// Obtain the SDR for a certain value
SDR sdr = enc.getSDRForValue(System.currentTimeMillis(),2,6);
~~~~

Class references;  
 * [TestDateTimeValuesEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestDateTimeValuesEncoder.java)
 * [DateTimeValuesEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/DateTimeValuesEncoder.java)
 * [DateTimeEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/DateTimeEncoder.java)
 * [CombinedEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/CombinedEncoder.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows;  
 * How the generated SDRs represent several date/time and value combinations.
 * The StringBuilder representation of the encoder state.
~~~~
SDR for 2019-01-01 00:00:00:000, value1: 0, value2: 0; 11111100000000000000000000000000000000000000001111111110000000000000000000000000000000000000000100000000001000111001011000000000000000010010000000000110110000000010100000100000000000111111110000000000
SDR for 2019-02-02 01:00:00:000, value1: 1, value2: 2; 11111111000000000000000000000000000000000000000000001111111100000000000000000000000000000000000000001000001000111001001000000000000000010000000000000111110000010000100000100000111100000000000000001111
SDR for 2019-03-03 02:00:00:000, value1: 2, value2: 4; 00111111110000000000000000000000000000000000000000000000111111110000000000000000000000000000000001001000001000111001001000000000000000000000000000000110110000010000100011000000111111110000000000000000
SDR for 2019-04-04 03:00:00:000, value1: 3, value2: 6; 00111111110000000000000000000000000000000000000000000000000011111111000000000000000000000000000001001000000000111001001000000000100000000000000000000010100000110000100011001000000000000000011111111000
SDR for 2019-05-05 04:00:00:000, value1: 4, value2: 8; 00001111111100000000000000000000000000000000000000000000000000001111111100000000000000000000000001000000000001111001001000000000100000000000000010000010100000010100000011001000111111110000000000000000

Encoder StringBuilder:
VALUE1=0.0,16,19,21,22,39,10,14,15;1.0,16,19,4,22,39,10,14,15;2.0,16,1,19,4,22,10,14,15;3.0,16,32,1,19,4,22,14,15;4.0,16,32,1,19,22,13,14,15|VALUE2=0.0,16,17,2,34,26,28,13,14;1.0,16,17,34,23,26,28,13,14;2.0,16,17,34,23,28,13,14,15;3.0,16,17,33,34,23,28,13,14;4.0,16,32,17,33,23,28,13,14;5.0,16,32,33,22,23,28,13,14;6.0,16,32,33,36,22,23,28,14;7.0,16,32,33,36,23,8,28,14;8.0,16,32,33,36,23,8,25,14
~~~~

nl.zeesoft.zdk.test.impl.htm.TestDateTimeValueEncoder
-----------------------------------------------------
This test shows how to create and scale a *DateTimeValueEncoder*.
A *DateTimeValueEncoder* can be used to customize value to SDR translation for date and time related values.
By default it merely translates values into scalar SDRs.
it can be customized to include periodic date and/or time representations into the encoded SDRs.

**Example implementation**  
~~~~
// Create the encoder
DateTimeValueEncoder enc = new DateTimeValueEncoder();
// Customize the encoder scale
enc.setScale(2);
// Obtain the SDR for a certain value
SDR sdr = enc.getSDRForValue(dateTime,value);
~~~~

Class references;  
 * [TestDateTimeValueEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestDateTimeValueEncoder.java)
 * [DateTimeValueEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/DateTimeValueEncoder.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows;  
 * How scaling changes the output length and bits of the SDRs the encoder will generate.
 * The JSON structure of the encoder.
~~~~
DateTimeValueEncoder length: 256, bits: 32
- VALUE ScalarEncoder length: 256, bits: 32, resolution: 1.0, min: 0.0, max: 100.0, periodic: false

DateTimeValueEncoder length: 512, bits: 64
- VALUE ScalarEncoder length: 512, bits: 64, resolution: 1.0, min: 0.0, max: 100.0, periodic: false

DateTimeValueEncoder length: 1024, bits: 128
- VALUE ScalarEncoder length: 1024, bits: 128, resolution: 1.0, min: 0.0, max: 100.0, periodic: false

Encoder JSON;
{
  "scale": 4,
  "includeMonth": false,
  "includeDayOfWeek": false,
  "includeHourOfDay": false,
  "includeMinute": false,
  "includeSecond": false,
  "includeValue": true,
  "valueMin": 0,
  "valueMax": 100,
  "valueResolution": 1.0,
  "valueDistributed": false
}
~~~~

nl.zeesoft.zdk.test.impl.htm.TestGridEncoder
--------------------------------------------
This test shows how to use a *GridEncoder* to convert a range of multidimensional positions into sparse distributed representations.
The *GridEncoder* class provides static helper methods to create different type of 2D or 3D encoders.

**Example implementation**  
~~~~
// Create the encoder
GridEncoder enc = GridEncoder.getNew2DGridEncoder(length,bits,sizeX,sizeY);
// Obtain the SDR for a certain position
SDR sdr = enc.getSDRForPosition(0,0);
~~~~

Class references;  
 * [TestGridEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestGridEncoder.java)
 * [GridEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/enc/GridEncoder.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows different grid encoders and the SDRs they generate for several positions.
~~~~
GridEncoder length: 128, bits: 16
- D01 GridDimensionEncoder length: 48, bits: 6, resolution: 1.0, capacity: 1664
  - 001 ScalarEncoder length: 16, bits: 2, resolution: 1.0, min: 0.0, max: 16.0, periodic: true
  - 002 ScalarEncoder length: 16, bits: 2, resolution: 14.0, min: 0.0, max: 224.0, periodic: true
  - 003 ScalarEncoder length: 16, bits: 2, resolution: 52.0, min: 0.0, max: 832.0, periodic: true
- D02 GridDimensionEncoder length: 80, bits: 10, resolution: 1.0, capacity: 14336
  - 001 ScalarEncoder length: 16, bits: 2, resolution: 1.0, min: 0.0, max: 16.0, periodic: true
  - 002 ScalarEncoder length: 16, bits: 2, resolution: 14.0, min: 0.0, max: 224.0, periodic: true
  - 003 ScalarEncoder length: 16, bits: 2, resolution: 52.0, min: 0.0, max: 832.0, periodic: true
  - 004 ScalarEncoder length: 16, bits: 2, resolution: 135.0, min: 0.0, max: 2160.0, periodic: true
  - 005 ScalarEncoder length: 16, bits: 2, resolution: 224.0, min: 0.0, max: 3584.0, periodic: true

SDR for position 00,00: 11000000000000001100000000000000110000000000000011000000000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 01,01: 01100000000000001100000000000000110000000000000001100000000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 02,02: 00110000000000001100000000000000110000000000000000110000000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 03,03: 00011000000000001100000000000000110000000000000000011000000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 04,04: 00001100000000001100000000000000110000000000000000001100000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 05,05: 00000110000000001100000000000000110000000000000000000110000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 06,06: 00000011000000001100000000000000110000000000000000000011000000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 07,07: 00000001100000001100000000000000110000000000000000000001100000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 08,08: 00000000110000001100000000000000110000000000000000000000110000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 09,09: 00000000011000001100000000000000110000000000000000000000011000001100000000000000110000000000000011000000000000001100000000000000
SDR for position 10,10: 00000000001100001100000000000000110000000000000000000000001100001100000000000000110000000000000011000000000000001100000000000000
SDR for position 11,11: 00000000000110001100000000000000110000000000000000000000000110001100000000000000110000000000000011000000000000001100000000000000
SDR for position 12,12: 00000000000011001100000000000000110000000000000000000000000011001100000000000000110000000000000011000000000000001100000000000000
SDR for position 13,13: 00000000000001101100000000000000110000000000000000000000000001101100000000000000110000000000000011000000000000001100000000000000
SDR for position 14,14: 00000000000000110110000000000000110000000000000000000000000000110110000000000000110000000000000011000000000000001100000000000000
SDR for position 15,15: 10000000000000010110000000000000110000000000000010000000000000010110000000000000110000000000000011000000000000001100000000000000
SDR for position 16,16: 11000000000000000110000000000000110000000000000011000000000000000110000000000000110000000000000011000000000000001100000000000000
SDR for position 17,17: 01100000000000000110000000000000110000000000000001100000000000000110000000000000110000000000000011000000000000001100000000000000
SDR for position 18,18: 00110000000000000110000000000000110000000000000000110000000000000110000000000000110000000000000011000000000000001100000000000000
SDR for position 19,19: 00011000000000000110000000000000110000000000000000011000000000000110000000000000110000000000000011000000000000001100000000000000

GridEncoder length: 128, bits: 12
- D01 GridDimensionScaledEncoder length: 48, bits: 6, resolution: 1.0, capacity: 360
  - 001 ScalarEncoder length: 24, bits: 2, resolution: 1.0, min: 0.0, max: 24.0, periodic: true
  - 002 ScalarEncoder length: 24, bits: 4, resolution: 15.0, min: 0.0, max: 360.0, periodic: true
- D02 GridDimensionScaledEncoder length: 80, bits: 6, resolution: 1.0, capacity: 720
  - 001 ScalarEncoder length: 32, bits: 2, resolution: 1.0, min: 0.0, max: 32.0, periodic: true
  - 002 ScalarEncoder length: 48, bits: 4, resolution: 15.0, min: 0.0, max: 720.0, periodic: true

SDR for position 00,00: 11000000000000000000000011110000000000000000000011000000000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 01,01: 01100000000000000000000011110000000000000000000001100000000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 02,02: 00110000000000000000000011110000000000000000000000110000000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 03,03: 00011000000000000000000011110000000000000000000000011000000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 04,04: 00001100000000000000000011110000000000000000000000001100000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 05,05: 00000110000000000000000011110000000000000000000000000110000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 06,06: 00000011000000000000000011110000000000000000000000000011000000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 07,07: 00000001100000000000000011110000000000000000000000000001100000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 08,08: 00000000110000000000000011110000000000000000000000000000110000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 09,09: 00000000011000000000000011110000000000000000000000000000011000000000000000000000111100000000000000000000000000000000000000000000
SDR for position 10,10: 00000000001100000000000011110000000000000000000000000000001100000000000000000000111100000000000000000000000000000000000000000000
SDR for position 11,11: 00000000000110000000000011110000000000000000000000000000000110000000000000000000111100000000000000000000000000000000000000000000
SDR for position 12,12: 00000000000011000000000011110000000000000000000000000000000011000000000000000000111100000000000000000000000000000000000000000000
SDR for position 13,13: 00000000000001100000000011110000000000000000000000000000000001100000000000000000111100000000000000000000000000000000000000000000
SDR for position 14,14: 00000000000000110000000011110000000000000000000000000000000000110000000000000000111100000000000000000000000000000000000000000000
SDR for position 15,15: 00000000000000011000000001111000000000000000000000000000000000011000000000000000011110000000000000000000000000000000000000000000
SDR for position 16,16: 00000000000000001100000001111000000000000000000000000000000000001100000000000000011110000000000000000000000000000000000000000000
SDR for position 17,17: 00000000000000000110000001111000000000000000000000000000000000000110000000000000011110000000000000000000000000000000000000000000
SDR for position 18,18: 00000000000000000011000001111000000000000000000000000000000000000011000000000000011110000000000000000000000000000000000000000000
SDR for position 19,19: 00000000000000000001100001111000000000000000000000000000000000000001100000000000011110000000000000000000000000000000000000000000

GridEncoder length: 512, bits: 50
- D01 GridDimensionScaledEncoder length: 224, bits: 20, resolution: 1.0, capacity: 4064
  - 001 ScalarEncoder length: 32, bits: 2, resolution: 1.0, min: 0.0, max: 32.0, periodic: true
  - 002 ScalarEncoder length: 64, bits: 4, resolution: 15.0, min: 0.0, max: 960.0, periodic: true
  - 003 ScalarEncoder length: 96, bits: 6, resolution: 53.0, min: 0.0, max: 5088.0, periodic: true
  - 004 ScalarEncoder length: 32, bits: 8, resolution: 127.0, min: 0.0, max: 4064.0, periodic: true
- D02 GridDimensionScaledEncoder length: 288, bits: 30, resolution: 1.0, capacity: 11952
  - 001 ScalarEncoder length: 24, bits: 2, resolution: 1.0, min: 0.0, max: 24.0, periodic: true
  - 002 ScalarEncoder length: 48, bits: 4, resolution: 15.0, min: 0.0, max: 720.0, periodic: true
  - 003 ScalarEncoder length: 72, bits: 6, resolution: 53.0, min: 0.0, max: 3816.0, periodic: true
  - 004 ScalarEncoder length: 96, bits: 8, resolution: 127.0, min: 0.0, max: 12192.0, periodic: true
  - 005 ScalarEncoder length: 48, bits: 10, resolution: 249.0, min: 0.0, max: 11952.0, periodic: true

SDR for position 00,00: 11000000000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000110000000000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 01,01: 01100000000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000011000000000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 02,02: 00110000000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000001100000000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 03,03: 00011000000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000110000000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 04,04: 00001100000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000011000000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 05,05: 00000110000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000001100000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 06,06: 00000011000000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000110000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 07,07: 00000001100000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000011000000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 08,08: 00000000110000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000001100000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 09,09: 00000000011000000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000110000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 10,10: 00000000001100000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000011000000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 11,11: 00000000000110000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000001100000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 12,12: 00000000000011000000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000110000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 13,13: 00000000000001100000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000011000000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 14,14: 00000000000000110000000000000000111100000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000001100000000111100000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 15,15: 00000000000000011000000000000000011110000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000000110000000011110000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 16,16: 00000000000000001100000000000000011110000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000000011000000011110000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 17,17: 00000000000000000110000000000000011110000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000000001100000011110000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 18,18: 00000000000000000011000000000000011110000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000000000110000011110000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
SDR for position 19,19: 00000000000000000001100000000000011110000000000000000000000000000000000000000000000000000000000011111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111000000000000000000000000000000000000000000011000011110000000000000000000000000000000000000000000111111000000000000000000000000000000000000000000000000000000000000000000111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111100000000000000000000000000000000000000
~~~~

nl.zeesoft.zdk.test.impl.htm.TestPooler
---------------------------------------
This test shows how to use a *Pooler* to convert encoder output SDRs into consistently sparse representations.

**Example implementation**  
~~~~
// Create the configuration
PoolerConfig config = new PoolerConfig(200,1024,21);
// Create the pooler
Pooler pooler = new Pooler(config);
// Randomize the connections
pooler.randomizeConnections();
// Obtain the output SDR for a certain input SDR
SDR sdr = pooler.getSDRForInput(new SDR(100),true);
~~~~

This test uses the *MockRegularSDRMap*.

Class references;  
 * [TestPooler](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestPooler.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)
 * [PoolerConfig](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/proc/PoolerConfig.java)
 * [Pooler](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/proc/Pooler.java)

**Test output**  
The output of this test shows information about the pooler after passing the SDR test set through it.  
It asserts that learning increases the difference in overlap between the regular weekly recurring values and all the other pooler output SDRs.  
~~~~
Initializing pooler took: 21 ms
Randomizing connections took: 60 ms

Pooler input dimensions: 16*16, output dimensions: 32*32
- Total proximal links: 92160, active: 46274
- Average proximal inputs per column: 90
- Column groups: 144, average columns per group: 441

Processing input SDR map (learning: false) ...
Processing input SDR map took: 8318 ms

Performance statistics;
calculateOverlapScores:       1901.247 ms
selectActiveColumns:           917.802 ms
logActivity:                  1084.394 ms
calculateColumnGroupActivity: 2856.538 ms
updateBoostFactors:           1290.593 ms
total:                        8115.859 ms
logSize:                         15330   
avgPerLog:                       0.529 ms

Combined average: 0.40603095, Combined weekly average: 4.5751457

Processing input SDR map (learning: true) ...
Processing input SDR map took: 12563 ms

Performance statistics;
calculateOverlapScores:        2652.434 ms
selectActiveColumns:           1026.659 ms
logActivity:                   1388.420 ms
calculateColumnGroupActivity:  3078.115 ms
updateBoostFactors:            1322.624 ms
total:                        12345.156 ms
learnActiveColumnsOnBits:      2806.876 ms
logSize:                          15330   
avgPerLog:                        0.805 ms

Combined average: 0.35102707, Combined weekly average: 6.2994227

Original ratio: 11.267973, learned ratio: 17.94569
~~~~

nl.zeesoft.zdk.test.impl.htm.TestMemory
---------------------------------------
This test shows how to use a *Memory* instance to learn temporal sequences of SDRs.  

**Please note** that this implementation differs greatly from the Numenta HTM implementation because it does not model dendrites;  
Memory cells are directly connected to each other and dendrite activation is not limited.  
Further more, distal connections do not need to be randomly initialized when the memory is created.  

**Example implementation**  
~~~~
// Create the configuration
MemoryConfig config = new MemoryConfig(1024);
// Create the memory
Memory memory = new Memory(config);
// Obtain the output SDR for a certain input SDR
SDR sdr = memory.getSDRForInput(new SDR(100),true);
~~~~

This test uses the *MockRegularSDRMap*.

Class references;  
 * [TestMemory](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestMemory.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)
 * [MemoryConfig](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/proc/MemoryConfig.java)
 * [Memory](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/proc/Memory.java)

**Test output**  
The output of this test shows;  
 * How memory column bursting is reduced after leaning several sequences  
 * Information about the memory after passing the SDR test set through it  
~~~~
Memory dimensions: 32*32*4

Processing input SDR map (5000/15330) ...
Processed SDRs: 500, bursting average: 4 (max: 11)
Processed SDRs: 1000, bursting average: 2 (max: 7)
Processed SDRs: 1500, bursting average: 2 (max: 9)
Processed SDRs: 2000, bursting average: 0 (max: 5)
Processed SDRs: 2500, bursting average: 1 (max: 5)
Processed SDRs: 3000, bursting average: 1 (max: 4)
Processed SDRs: 3500, bursting average: 0 (max: 3)
Processed SDRs: 4000, bursting average: 1 (max: 4)
Processed SDRs: 4500, bursting average: 0 (max: 4)
Processed SDRs: 5000, bursting average: 0 (max: 3)
Processing input SDR map took: 14936 ms

Performance statistics;
cycleActiveState:       274.231 ms
activateColumnCells:    233.870 ms
calculateActivity:     1039.803 ms
selectPredictiveCells:  468.416 ms
updatePredictions:     4240.358 ms
total:                 6269.317 ms
logSize:                   5000   
avgPerLog:                1.254 ms

Memory dimensions: 32*32*4
- Total distal links: 233131, active: 221842
- Average distal inputs per memory cell: 56 (min: 21, max: 105)
- Average connected distal inputs per memory cell: 54 (min: 12, max: 105)
~~~~

nl.zeesoft.zdk.test.impl.htm.TestMerger
---------------------------------------
This test shows how to use a *Merger* to merge multiple SDRs into a single SDR.

**Example implementation**  
~~~~
// Create the merger
Merger merger = new Merger(new MergerConfig());
// Create an input SDR
SDR sdr = new SDR(100);
sdr.setBit(0,true);
// Create a context SDR list
SDR sdr2 = new SDR(100);
sdr2.setBit(0,true);
List<SDR> context = new ArrayList<SDR>();
context.add(sdr2);
// Obtain the output SDRs for the input SDR and its context SDRs
Lis<SDR> outputSDRs = merger.getSDRsForInput(sdr,context,false);
~~~~

Class references;  
 * [TestMerger](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestMerger.java)
 * [Merger](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/proc/Merger.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)

**Test output**  
The output of this test shows a description of the merger and the result of several SDR merges.  
~~~~
Merger maximum number of on bits: 4

Input SDR: 50,0,24
Context SDR: 50,0,24
Merged SDR: 100,0,50,24,74

Context SDR 1: 50,0,24
Context SDR 2: 50,0,24
Merged SDR: 100,0,50,24,74
~~~~

nl.zeesoft.zdk.test.impl.htm.TestZGridColumnEncoders
----------------------------------------------------
This test shows the configuration options of several *ZGridColumnEncoder* instances.  
*ZGridColumnEncoder* instances are used to translate *ZGrid* request values into SDRs for further grid processing.  

**Example implementation**  
~~~~
// Create a date/time grid encoder
ZGridEncoderDateTime dateTimeEncoder = new ZGridEncoderDateTime();
// Transform the encoder to JSON
JsFile json = dateTimeEncoder.toJson();
// Configure the encoder using JSON
dateTimeEncoder.fromJson(json);
~~~~

Class references;  
 * [TestZGridColumnEncoders](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestZGridColumnEncoders.java)
 * [ZGridColumnEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/ZGridColumnEncoder.java)
 * [ZGrid](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/ZGrid.java)
 * [SDR](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/util/SDR.java)
 * [ZGridEncoderDateTime](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/enc/ZGridEncoderDateTime.java)
 * [ZGridEncoderValue](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/enc/ZGridEncoderValue.java)
 * [ZGridEncoderProperty](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/enc/ZGridEncoderProperty.java)

**Test output**  
The output of this test shows the JSON representations of several encoders  
~~~~
Date/time encoder JSON:
{
  "scale": 4,
  "bitsPerEncoder": 24,
  "includeMonth": true,
  "includeDayOfWeek": true,
  "includeHourOfDay": true,
  "includeMinute": true,
  "includeSecond": true
}

Value encoder JSON:
{
  "type": "DIMENSIONAL",
  "length": 256,
  "bits": 8,
  "resolution": 1.0,
  "minValue": 0.0,
  "maxValue": 247.0,
  "periodic": false,
  "valueKey": "VALUE"
}

Property encoder JSON:
{
  "length": 256,
  "bits": 8,
  "valueKey": "PROPERTY"
}
~~~~

nl.zeesoft.zdk.test.impl.htm.TestZGrid
--------------------------------------
This test shows how to create and configure a *ZGrid* instance to learn and predict sequences of values.
A *ZGrid* consists of several rows and columns where each column can process a certain input value.
It uses multithreading to maximize the throughput of grid requests.
The first row of a *ZGrid* is reserved for *ZGridColumnEncoder* objects that translate request input values into SDRs.
The remaining rows can be used for *Pooler*, *Memory*, *Classifier*, *Merger* and custom processors.
Context routing can be used to route the output of a column to the context of another column.

**Example implementation**  
~~~~
// Create the grid
ZGrid grid = new ZGrid(4,2);
// Add encoders
grid.setEncoder(0,new ZGridEncoderDateTime());
grid.setEncoder(1,new ZGridEncoderValue(256));
// Add processors
grid.setProcessor(1,0,new PoolerConfig(256,1024,21));
grid.setProcessor(1,1,new PoolerConfig(256,1024,21));
MemoryConfig config = new MemoryConfig(1024,21);
config.addContextDimension(1024);
grid.setProcessor(2,1,config);
grid.setProcessor(3,1,new ClassifierConfig(1));
// Route output from date/time pooler to value memory context
grid.addColumnContext(2,1,1,0);
// Route output from value encoder to value classifier context
grid.addColumnContext(3,1,0,1);
// Add a listener for grid results
grid.addListener(this);
// Randomize grid pooler connections
grid.randomizePoolerConnections();
// Start the grid
grid.start();
// Add requests
ZGridRequest request = grid.getNewRequest();
request.inputValues[0] = request.datetime;
request.inputValues[1] = 1F;
request.inputLabels[1] = "Normal";
long requestId = grid.addRequest(request);
// Remember to stop and destroy the grid after use
grid.stop();
grid.whileActive();
grid.destroy();
~~~~

Class references;  
 * [TestZGrid](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/test/impl/htm/TestZGrid.java)
 * [ZGrid](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/ZGrid.java)
 * [ZGridRequest](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/ZGridRequest.java)
 * [ZGridColumnEncoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V4.0/ZDK/src/nl/zeesoft/zdk/htm/grid/ZGridColumnEncoder.java)

**Test output**  
The output of this test shows;  
 * A description of the grid after initialization  
 * A JSON representation of the grid configuration  
 * The classifier prediction accuracy of the grid while processing requests   
 * A description of the grid after processing requests  
 * The size of the state data for each grid processor  
~~~~
Grid dimensions: 5*5
- Column 00-00 = CombinedEncoder length: 128, bits: 32
  - SECOND ScalarEncoder length: 128, bits: 32, resolution: 1.0, min: 0.0, max: 60.0, periodic: true
- Column 00-01 = CombinedEncoder length: 256, bits: 16
  - VALUE ScalarEncoder length: 256, bits: 16, resolution: 1.0, min: 0.0, max: 30.0, periodic: false
- Column 00-02 = CombinedEncoder length: 64, bits: 8
  - POSX ScalarEncoder length: 64, bits: 8, resolution: 1.0, min: 0.0, max: 20.0, periodic: false
- Column 00-03 = CombinedEncoder length: 64, bits: 8
  - POSY ScalarEncoder length: 64, bits: 8, resolution: 1.0, min: 0.0, max: 20.0, periodic: false
- Column 00-04 = CombinedEncoder length: 64, bits: 8
  - POSZ ScalarEncoder length: 64, bits: 8, resolution: 1.0, min: 0.0, max: 20.0, periodic: false
- Column 01-03 = Merger maximum number of on bits: 0
- Column 02-00 = Pooler input dimensions: 12*11, output dimensions: 32*32
  - Total proximal links: 89600, active: 44698
  - Average proximal inputs per column: 87 (min: 87, max: 88)
  - Column groups: 144, average columns per group: 441
- Column 02-01 = Pooler input dimensions: 16*16, output dimensions: 32*32
  - Total proximal links: 92160, active: 46502
  - Average proximal inputs per column: 90
  - Column groups: 144, average columns per group: 441
- Column 02-03 = Pooler input dimensions: 14*14, output dimensions: 32*32
  - Total proximal links: 91776, active: 45806
  - Average proximal inputs per column: 89 (min: 87, max: 90)
  - Column groups: 144, average columns per group: 441
- Column 03-01 = Memory dimensions: 32*32*4
- Column 04-00 = Detector start: 2500, window long/short: 500/1, threshold: 0.3
- Column 04-01 = Classifier value key: VALUE, predict steps: 1

Grid JSON;
{
  "rows": 5,
  "columns": 5,
  "configurations": [
    {
      "columnId": "00-00",
      "className": "nl.zeesoft.zdk.htm.grid.enc.ZGridEncoderDateTime",
      "scale": 2,
      "bitsPerEncoder": 32,
      "includeMonth": false,
      "includeDayOfWeek": false,
      "includeHourOfDay": false,
      "includeMinute": false,
      "includeSecond": true
    },
    {
      "columnId": "00-01",
      "className": "nl.zeesoft.zdk.htm.grid.enc.ZGridEncoderValue",
      "type": "SCALAR",
      "length": 256,
      "bits": 16,
      "resolution": 1.0,
      "minValue": 0.0,
      "maxValue": 30.0,
      "periodic": false,
      "valueKey": "VALUE"
    },
    {
      "columnId": "00-02",
      "className": "nl.zeesoft.zdk.htm.grid.enc.ZGridEncoderValue",
      "type": "SCALAR",
      "length": 64,
      "bits": 8,
      "resolution": 1.0,
      "minValue": 0.0,
      "maxValue": 20.0,
      "periodic": false,
      "valueKey": "POSX"
    },
    {
      "columnId": "00-03",
      "className": "nl.zeesoft.zdk.htm.grid.enc.ZGridEncoderValue",
      "type": "SCALAR",
      "length": 64,
      "bits": 8,
      "resolution": 1.0,
      "minValue": 0.0,
      "maxValue": 20.0,
      "periodic": false,
      "valueKey": "POSY"
    },
    {
      "columnId": "00-04",
      "className": "nl.zeesoft.zdk.htm.grid.enc.ZGridEncoderValue",
      "type": "SCALAR",
      "length": 64,
      "bits": 8,
      "resolution": 1.0,
      "minValue": 0.0,
      "maxValue": 20.0,
      "periodic": false,
      "valueKey": "POSZ"
    },
    {
      "columnId": "01-03",
      "className": "nl.zeesoft.zdk.htm.proc.MergerConfig",
      "union": false,
      "maxOnBits": 0,
      "contexts": [
        {
          "sourceRow": 0,
          "sourceColumn": 2,
          "sourceIndex": 0
        },
        {
          "sourceRow": 0,
          "sourceColumn": 4,
          "sourceIndex": 0
        }
      ]
    },
    {
      "columnId": "02-00",
      "className": "nl.zeesoft.zdk.htm.proc.PoolerConfig",
      "inputLength": 128,
      "outputLength": 1024,
      "outputBits": 21,
      "inputSizeX": 12,
      "inputSizeY": 11,
      "outputSizeX": 32,
      "outputSizeY": 32,
      "potentialProximalConnections": 0.75,
      "proximalRadius": 5,
      "proximalConnectionThreshold": 0.1,
      "proximalConnectionDecrement": 0.008,
      "proximalConnectionIncrement": 0.05,
      "boostStrength": 10,
      "boostInhibitionRadius": 10,
      "boostActivityLogSize": 100
    },
    {
      "columnId": "02-01",
      "className": "nl.zeesoft.zdk.htm.proc.PoolerConfig",
      "inputLength": 256,
      "outputLength": 1024,
      "outputBits": 21,
      "inputSizeX": 16,
      "inputSizeY": 16,
      "outputSizeX": 32,
      "outputSizeY": 32,
      "potentialProximalConnections": 0.75,
      "proximalRadius": 5,
      "proximalConnectionThreshold": 0.1,
      "proximalConnectionDecrement": 0.008,
      "proximalConnectionIncrement": 0.05,
      "boostStrength": 10,
      "boostInhibitionRadius": 10,
      "boostActivityLogSize": 100
    },
    {
      "columnId": "02-03",
      "className": "nl.zeesoft.zdk.htm.proc.PoolerConfig",
      "inputLength": 192,
      "outputLength": 1024,
      "outputBits": 21,
      "inputSizeX": 14,
      "inputSizeY": 14,
      "outputSizeX": 32,
      "outputSizeY": 32,
      "potentialProximalConnections": 0.75,
      "proximalRadius": 5,
      "proximalConnectionThreshold": 0.1,
      "proximalConnectionDecrement": 0.008,
      "proximalConnectionIncrement": 0.05,
      "boostStrength": 10,
      "boostInhibitionRadius": 10,
      "boostActivityLogSize": 100
    },
    {
      "columnId": "03-01",
      "className": "nl.zeesoft.zdk.htm.proc.MemoryConfig",
      "length": 1024,
      "sizeX": 32,
      "sizeY": 32,
      "bits": 21,
      "depth": 4,
      "maxDistalConnectionsPerCell": 9999,
      "localDistalConnectedRadius": 64,
      "minAlmostActiveDistalConnections": 5,
      "distalConnectionThreshold": 0.2,
      "distalConnectionDecrement": 0.003,
      "distalConnectionIncrement": 0.1,
      "contextDimensions": "1024,1024",
      "contexts": [
        {
          "sourceRow": 2,
          "sourceColumn": 0,
          "sourceIndex": 0
        },
        {
          "sourceRow": 2,
          "sourceColumn": 3,
          "sourceIndex": 0
        }
      ]
    },
    {
      "columnId": "04-00",
      "className": "nl.zeesoft.zdk.htm.proc.DetectorConfig",
      "start": 2500,
      "windowLong": 500,
      "windowShort": 1,
      "threshold": 0.3,
      "contexts": [
        {
          "sourceRow": 2,
          "sourceColumn": 1,
          "sourceIndex": 0
        },
        {
          "sourceRow": 3,
          "sourceColumn": 1,
          "sourceIndex": 1
        }
      ]
    },
    {
      "columnId": "04-01",
      "className": "nl.zeesoft.zdk.htm.proc.ClassifierConfig",
      "predictSteps": "1",
      "valueKey": "VALUE",
      "labelKey": "LABEL",
      "maxCount": 40,
      "contexts": [
        {
          "sourceRow": 0,
          "sourceColumn": 1,
          "sourceIndex": 0
        }
      ]
    }
  ]
}

Added requests
2019-12-23 19:22:25:629 DBG nl.zeesoft.zdk.htm.grid.ZGrid: Starting grid ...
2019-12-23 19:22:25:631 DBG nl.zeesoft.zdk.htm.grid.ZGrid: Started grid
Processed requests: 100, accuracy: 0.544
Processed requests: 200, accuracy: 0.738
Processed requests: 300, accuracy: 0.826
Processed requests: 400, accuracy: 0.867
Processed requests: 500, accuracy: 0.892
Processed requests: 600, accuracy: 0.904
Processed requests: 700, accuracy: 0.915
Processed requests: 800, accuracy: 0.926
Processed requests: 900, accuracy: 0.934
Processed requests: 1000, accuracy: 0.940
Processed requests: 1100, accuracy: 0.974
Processed requests: 1200, accuracy: 0.981
Processed requests: 1300, accuracy: 0.981
Processed requests: 1400, accuracy: 0.979
Processed requests: 1500, accuracy: 0.973
Processed requests: 1600, accuracy: 0.970
Processed requests: 1700, accuracy: 0.971
Processed requests: 1800, accuracy: 0.969
Processed requests: 1900, accuracy: 0.968
Processed requests: 2000, accuracy: 0.965
Processed requests: 2100, accuracy: 0.965 (!)
Processed requests: 2200, accuracy: 0.968
Processed requests: 2300, accuracy: 0.973
Processed requests: 2400, accuracy: 0.969
Processed requests: 2500, accuracy: 0.968
Processed requests: 2600, accuracy: 0.969
Processed requests: 2700, accuracy: 0.975
Detected anomaly at id 2743, detected: 0.47619045, average: 0.98457223, difference: 0.34802485
Detected anomaly at id 2745, detected: 0.52380955, average: 0.9828579, difference: 0.30467796
Detected anomaly at id 2746, detected: 0.47619045, average: 0.9820007, difference: 0.34687513
Detected anomaly at id 2753, detected: 0.4285714, average: 0.97771496, difference: 0.39049196
Processed requests: 2800, accuracy: 0.935
Processed requests: 2900, accuracy: 0.931
Processed requests: 3000, accuracy: 0.927
2019-12-23 19:22:39:816 DBG nl.zeesoft.zdk.htm.grid.ZGrid: Stopping grid ...
2019-12-23 19:22:39:979 DBG nl.zeesoft.zdk.htm.grid.ZGrid: Stopped grid
Processing 3000 requests took 14432 ms

Grid dimensions: 5*5
- Column 00-00 = CombinedEncoder length: 128, bits: 32
  - SECOND ScalarEncoder length: 128, bits: 32, resolution: 1.0, min: 0.0, max: 60.0, periodic: true
- Column 00-01 = CombinedEncoder length: 256, bits: 16
  - VALUE ScalarEncoder length: 256, bits: 16, resolution: 1.0, min: 0.0, max: 30.0, periodic: false
- Column 00-02 = CombinedEncoder length: 64, bits: 8
  - POSX ScalarEncoder length: 64, bits: 8, resolution: 1.0, min: 0.0, max: 20.0, periodic: false
- Column 00-03 = CombinedEncoder length: 64, bits: 8
  - POSY ScalarEncoder length: 64, bits: 8, resolution: 1.0, min: 0.0, max: 20.0, periodic: false
- Column 00-04 = CombinedEncoder length: 64, bits: 8
  - POSZ ScalarEncoder length: 64, bits: 8, resolution: 1.0, min: 0.0, max: 20.0, periodic: false
- Column 01-03 = Merger maximum number of on bits: 0
- Column 02-00 = Pooler input dimensions: 12*11, output dimensions: 32*32
  - Total proximal links: 89600, active: 50194
  - Average proximal inputs per column: 87 (min: 87, max: 88)
  - Column groups: 144, average columns per group: 441
- Column 02-01 = Pooler input dimensions: 16*16, output dimensions: 32*32
  - Total proximal links: 92160, active: 34216
  - Average proximal inputs per column: 90
  - Column groups: 144, average columns per group: 441
- Column 02-03 = Pooler input dimensions: 14*14, output dimensions: 32*32
  - Total proximal links: 91776, active: 34538
  - Average proximal inputs per column: 89 (min: 87, max: 90)
  - Column groups: 144, average columns per group: 441
- Column 03-01 = Memory dimensions: 32*32*4
  - Total distal links: 208585, active: 195384
  - Average distal inputs per memory cell: 50 (min: 0, max: 126)
  - Average connected distal inputs per memory cell: 47 (min: 0, max: 126)
  - Average connected distal context inputs per memory cell: 33 (min: 0, max: 84)
- Column 04-00 = Detector start: 2500, window long/short: 500/1, threshold: 0.3 (ACTIVE)
- Column 04-01 = Classifier value key: VALUE, predict steps: 1

Grid column state data;
- 02-00: 832262
- 02-01: 946675
- 02-03: 894925
- 03-01: 4095989
- 04-00: 3016
- 04-01: 123481
Loading state data took 1940 ms
~~~~

Test results
------------
All 24 tests have been executed successfully (279286 assertions).  
Total test duration: 68405 ms (total sleep duration: 19000 ms).  

Memory usage per test;  
 * nl.zeesoft.zdk.test.impl.TestZStringEncoder: 757 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestZStringSymbolParser: 524 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestCsv: 531 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestJson: 545 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestZHttpRequest: 557 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestMessenger: 763 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestZMatrix: 829 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestGeneticCode: 790 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.TestNeuralNet: 4260 Kb / 4 Mb
 * nl.zeesoft.zdk.test.impl.TestGeneticNN: 22477 Kb / 21 Mb
 * nl.zeesoft.zdk.test.impl.TestEvolver: 16208 Kb / 15 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestSDR: 15571 Kb / 15 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestSDRMap: 2541 Kb / 2 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestScalarEncoder: 946 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestRDScalarEncoder: 970 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestDateTimeEncoder: 977 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestDateTimeValuesEncoder: 971 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestDateTimeValueEncoder: 986 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestGridEncoder: 988 Kb / 0 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestPooler: 34940 Kb / 34 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestMemory: 34948 Kb / 34 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestMerger: 34959 Kb / 34 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestZGridColumnEncoders: 35024 Kb / 34 Mb
 * nl.zeesoft.zdk.test.impl.htm.TestZGrid: 35208 Kb / 34 Mb
