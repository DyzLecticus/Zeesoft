Zeesoft Development Kit
=======================
The Zeesoft Development Kit (ZDK) is an open source library for Java application development.

It provides support for;
 * [Advanced encoding and decoding](#nlzeesoftzdktestimpltestencoderdecoder).
 * [Extended StringBuilder manipulation](#nlzeesoftzdktestimpltestsymbolparser).
 * [Multi threading](#nlzeesoftzdktestimpltestmessenger).
 * [Application message handling](#nlzeesoftzdktestimpltestmessenger).
 * [Confabulation (artificial cognition)](#nlzeesoftzdktestimpltestconfabulatortraining).

**Release downloads**  
Click [here](https://github.com/DyzLecticus/Zeesoft/raw/master/V3.0/ZDK/releases/zdk-0.9.1.zip) to download the latest ZDK release (version 0.9.1).
All ZDK releases can be downloaded [here](https://github.com/DyzLecticus/Zeesoft/tree/master/V3.0/ZDK/releases).
ZDK releases contain the ZDK jar file (includes source code and build scripts), this README file, and a separate zip file containing the generated java documentation.

**Self documenting and self testing**  
The tests used to develop the ZDK are also used to generate this README file.
Run the [ZDK](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/ZDK.java) class as a java application to print this documentation to the standard out.
Click [here](#test-results) to scroll down to the test result summary.

nl.zeesoft.zdk.test.impl.TestEncoderDecoder
-------------------------------------------
This test shows how to use the *EncoderDecoder* class to generate a key and use that to encode and decode a text.

**Example implementation**  
~~~~
// Generate a key
String key = EncoderDecoder.generateNewKey(1024);
// Use the key to encode a text
StringBuilder encodedText = EncoderDecoder.encodeKey(new StringBuilder("Example text to be encoded."),key,0);
// Use the key to decode an encoded text
StringBuilder decodedText = EncoderDecoder.decodeKey(encodedText,key,0);
~~~~

This encoding mechanism can be used to encode and decode passwords and other sensitive data.
The minimum key length is 64. Longer keys provide stronger encoding.

Class references;  
 * [TestEncoderDecoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestEncoderDecoder.java)
 * [EncoderDecoder](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/EncoderDecoder.java)

**Test output**  
The output of this test shows the generated key, the input text, the encoded text, and the decoded text.
~~~~
Key: 4883146198648760630650622152728324971520819907512999712937518924
Input text: Hello, my name is Dyz Lecticus. How are you feeling today?
Encoded text: mzOAyA#zkxGzI#FyVBB~a:H#TAS~C#:x7:lx2wm:g#tvs#IyDysx0#7yS~ry~~uxwy1#LBu#0xf#Cy~wCAHyTBW~BxN~Y#9xpyQBIBs~J~bxhybAeze:0
Decoded text: Hello, my name is Dyz Lecticus. How are you feeling today?
~~~~

nl.zeesoft.zdk.test.impl.TestSymbolParser
-----------------------------------------
This test shows how to use the *SymbolParser* class to parse symbols (words and punctuation) from a certain text.

**Example implementation**  
~~~~
List<String> symbols = SymbolParser.parseSymbolsFromText(new StringBuilder("Example text."));
~~~~

The *SymbolParser* is used by confabulators to parse sequence and context text input.
It uses the extended StringBuilder manipulation functions of the *Generic* class to perform its task.

Class references;  
 * [TestSymbolParser](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestSymbolParser.java)
 * [SymbolParser](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/SymbolParser.java)
 * [Generic](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/Generic.java)

**Test output**  
The output of this test shows the input text and the parsed symbols separated by spaces.
~~~~
Input text: Hello, my name is Dyz Lecticus. How are you feeling today?
Parsed symbols: Hello , my name is Dyz Lecticus . How are you feeling today ?
~~~~

nl.zeesoft.zdk.test.impl.TestMessenger
--------------------------------------
This test reflects a default implementation of the *Messenger* singleton combined with the *WorkerUnion* singleton.

**Example implementation**  
~~~~
// Add a debug message
Messenger.getInstance().debug(this,"Example debug message");
// Add a warning message
Messenger.getInstance().warn(this,"Example warning message");
// Add an error message
Messenger.getInstance().setPrintDebugMessages(true);
// Start the messenger
Messenger.getInstance().start();
// Stop the messenger
Messenger.getInstance().error(this,"Example error message");
// Configure the messenger to print debug messages
Messenger.getInstance().stop();
// Ensure all application workers are stopped
WorkerUnion.getInstance().stopWorkers();
// Trigger the messenger to print the remaining messages
Messenger.getInstance().whileWorking();
~~~~

The *Messenger* can be used to log debug, warning and error messages and print them to the standard and/or error out.
It is implemented as a thread safe singleton to allow easy application wide access.
It implements the *Worker* class to minimize wait time impact for threads that call the *Messenger*.
Classes that implement the *MessengerListener* interface can subscribe to *Messenger* message printing events.
The *WorkerUnion* can be used to ensure all workers that have been started are stopped when stopping the application.
It will log a warning if it fails to stop a worker.

Class references;  
 * [TestMessenger](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestMessenger.java)
 * [Messenger](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/messenger/Messenger.java)
 * [MessengerListener](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/messenger/MessengerListener.java)
 * [Worker](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/thread/Worker.java)
 * [WorkerUnion](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/thread/WorkerUnion.java)

**Test output**  
The output of this test shows the standard (and error) output of the test log messages.
~~~~
2017-01-17 23:12:39:628 DBG java.lang.Object: Test log debug message before Messenger has started
2017-01-17 23:12:39:959 ERR java.lang.Object: Test log error message while Messenger is working
2017-01-17 23:12:40:260 WRN java.lang.Object: Test log warning message after Messenger has stopped
~~~~

nl.zeesoft.zdk.test.impl.TestConfabulatorTraining
-------------------------------------------------
This test shows how to create and train a *Confabulator* instance.

**Example implementation**  
~~~~
// Create confabulator
Confabulator confabulator = new Confabulator();
// Train confabulator
confabulator.learnSequence("Example symbol sequence.","Optional Example Context Symbols");
~~~~

A *Confabulator* can learn symbol sequences (i.e. sentences), optionally combined with certain context symbols (i.e. subject(s)).
When trained, a *Confabulator* can be used to;
 * Confabulate one or more context symbols for a certain input sequence.
 * Confabulate a correction for a certain input sequence, optionally restricted by one or more context symbols.
 * Confabulate a starter sequence or an extension for an input sequence, optionally restricted by one or more context symbols.

By default, confabulators limit their maximum link distance to 8 and their maximum link count to 1000.
Deviations from these defaults can be specified using the *Confabulator* initialization method.
When the link count of one of the links hits the specified count maximum, all *Confabulator* link counts are divided by 2.
Links that have a count of 1 are removed by this division process.
When repeatedly confronted with a slowly changing training set, this mechanism allows the *Confabulator* to slowly forget links that are no longer part of the training set.

The training set used by the *Confabulator* tests consists of the following sequence and context combinations;
 * *'What is your name? My name is Dyz Lecticus.' - 'I Self My Name'*
 * *'What is your goal? My goal is to model reality through interactions with people.' - 'I Self My Goal'*
 * *'What are you? I am an artificial cognition.' - 'I Self Am Artificial Cognition'*
 * *'Who created you? I was created by Andre van der Zee.' - 'I Self My Creator'*

Class references;  
 * [TestConfabulatorTraining](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestConfabulatorTraining.java)
 * [Confabulator](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/Confabulator.java)

**Test output**  
The output of this test shows a brief summary of the link data that is created based on the training set.
Please note the relatively large amount of links compared to the size of the training set.
~~~~
Link: 1, from: 'What', to: 'is', distance: 1, count: 4, context: 'I'
Link: 2, from: 'What', to: 'is', distance: 1, count: 4, context: 'Self'
Link: 3, from: 'What', to: 'is', distance: 1, count: 4, context: 'My'
Link: 4, from: 'What', to: 'is', distance: 1, count: 2, context: 'Name'
Link: 5, from: 'What', to: 'your', distance: 2, count: 4, context: 'I'
Link: 6, from: 'What', to: 'your', distance: 2, count: 4, context: 'Self'
Link: 7, from: 'What', to: 'your', distance: 2, count: 4, context: 'My'
Link: 8, from: 'What', to: 'your', distance: 2, count: 2, context: 'Name'
Link: 9, from: 'What', to: 'name', distance: 3, count: 2, context: 'I'

[ ... ]

Link: 1004, from: 'der', to: 'Zee', distance: 1, count: 2, context: 'I'
Link: 1005, from: 'der', to: 'Zee', distance: 1, count: 2, context: 'Self'
Link: 1006, from: 'der', to: 'Zee', distance: 1, count: 2, context: 'My'
Link: 1007, from: 'der', to: 'Zee', distance: 1, count: 2, context: 'Creator'
Link: 1008, from: 'der', to: '.', distance: 2, count: 2, context: 'I'
Link: 1009, from: 'der', to: '.', distance: 2, count: 2, context: 'Self'
Link: 1010, from: 'der', to: '.', distance: 2, count: 2, context: 'My'
Link: 1011, from: 'der', to: '.', distance: 2, count: 2, context: 'Creator'
Link: 1012, from: 'Zee', to: '.', distance: 1, count: 2, context: 'I'
Link: 1013, from: 'Zee', to: '.', distance: 1, count: 2, context: 'Self'
Link: 1014, from: 'Zee', to: '.', distance: 1, count: 2, context: 'My'
Link: 1015, from: 'Zee', to: '.', distance: 1, count: 2, context: 'Creator'
Total Links: 1015 (64 ms)
~~~~

nl.zeesoft.zdk.test.impl.TestConfabulatorContextConfabulation
-------------------------------------------------------------
This test shows how to use a trained *Confabulator* instance to confabulate one or more context symbols for a certain input sequence.

**Example implementation**  
~~~~
// Create confabulator
Confabulator confabulator = new Confabulator();
// Train confabulator
confabulator.learnSequence("Example symbol sequence.","Optional Context Symbols");
// Create ContextConfabulation
ContextConfabulation confabulation = new ContextConfabulation("Example");
// Confabulate
confabulator.confabulate(confabulation);
~~~~

Class references;  
 * [TestConfabulatorContextConfabulation](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestConfabulatorContextConfabulation.java)
 * [Confabulator](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/Confabulator.java)
 * [ContextConfabulation](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/confabulations/ContextConfabulation.java)

**Test output**  
The output of this test shows the confabulation input sequence, log summary, and output.
Please note how the confabulation process favours the most significant context symbol over the stronger associated context symbols.
~~~~
Confabulation input sequence: What is your name?
2017-01-17 23:12:40:418: Confabulated winning context symbol: Name
Module 01:  Name (786) My (564) Self (462) I (462) Goal (342)
Confabulation output: Name (32 ms)
~~~~

nl.zeesoft.zdk.test.impl.TestConfabulatorCorrectionConfabulation
----------------------------------------------------------------
This test shows how to use a trained *Confabulator* instance to confabulate a correction for a certain input sequence, optionally restricted by one or more context symbols.

**Example implementation**  
~~~~
// Create confabulator
Confabulator confabulator = new Confabulator();
// Train confabulator
confabulator.learnSequence("Example symbol sequence.","Optional Context Symbols");
// Create CorrectionConfabulation
CorrectionConfabulation confabulation = new CorrectionConfabulation("Example symbol bla.","Optional Context");
// Confabulate
confabulator.confabulate(confabulation);
~~~~

Class references;  
 * [TestConfabulatorCorrectionConfabulation](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestConfabulatorCorrectionConfabulation.java)
 * [Confabulator](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/Confabulator.java)
 * [CorrectionConfabulation](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/confabulations/CorrectionConfabulation.java)

**Test output**  
The output of this test shows the confabulation input sequence, log summary, and output for several confabulations;
 * One confabulation without context.
 * One confabulation with context.
Please note how the modules are used in the first confabulation to search all possible combinations.
~~~~
Confabulation input sequence: What is your bla?
2017-01-17 23:12:40:514: Confabulated replacement symbol: goal, for: bla
Module 06:  What (1)
Module 07:  is (1)
Module 08:  your (1)
Module 09:  goal (3496) name (2980)
Module 10:  ? (1)
Module 11:  My (4296) I (1003)
Module 12:  name (3024) goal (3024) am (1340) was (1104)
Module 13:  is (5588) an (1950) created (1584) ? (936)
Module 14:  to (4128) Dyz (4128) artificial (2520) by (2112) My (1866) ... [3]
Module 15:  model (4128) Lecticus (4128) cognition (3075) Andre (2580) name (2520) ... [4]
Module 16:  reality (4128) is (3368) . (3220) van (3096) I (2522) ... [4]
Confabulation output: What is your goal ? (48 ms)

Confabulation input sequence: What is your bla? (context: Name)
2017-01-17 23:12:40:518: Confabulated replacement symbol: name, for: bla
Module 06:  What (1)
Module 07:  is (1)
Module 08:  your (1)
Module 09:  name (495)
Module 10:  ? (1)
Confabulation output: What is your name ? (2 ms)
~~~~

nl.zeesoft.zdk.test.impl.TestConfabulatorExtensionConfabulation
---------------------------------------------------------------
This test shows how to use a trained *Confabulator* instance to confabulate a starter sequence or an extension for an input sequence, optionally restricted by one or more context symbols.

**Example implementation**  
~~~~
// Create confabulator
Confabulator confabulator = new Confabulator();
// Train confabulator
confabulator.learnSequence("Example symbol sequence.","Optional Context Symbols");
// Create ExtensionConfabulation
ExtensionConfabulation confabulation = new ExtensionConfabulation("Optional sequence symbols","Optional Context");
// Confabulate
confabulator.confabulate(confabulation);
~~~~

Class references;  
 * [TestConfabulatorExtensionConfabulation](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/test/impl/TestConfabulatorExtensionConfabulation.java)
 * [Confabulator](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/Confabulator.java)
 * [ExtensionConfabulation](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDK/src/nl/zeesoft/zdk/confabulator/confabulations/ExtensionConfabulation.java)

**Test output**  
The output of this test shows the confabulation input sequence, log summary, and output for several confabulations;
 * One confabulation without an input sequence.
 * One confabulation without context.
 * Two confabulations with context.
Please note how the confabulated extension can vary depending on the (lack of) context.
~~~~
Confabulation input sequence: 
2017-01-17 23:12:40:587: Confabulated first symbol: What
Module 09:  What (12183) Who (4192)
2017-01-17 23:12:40:588: Confabulated next symbol: are
Module 08:  What (1)
Module 09:  are (745) is (740)
2017-01-17 23:12:40:589: Confabulated next symbol: you
Module 07:  What (1)
Module 08:  are (1)
Module 09:  you (1390)
2017-01-17 23:12:40:590: Confabulated next symbol: ?
Module 06:  What (1)
Module 07:  are (1)
Module 08:  you (1)
Module 09:  ? (2089)
Confabulation output: What are you ? (13 ms)

Confabulation input sequence: What is artificial cognition?
2017-01-17 23:12:40:592: Confabulated next symbol: My
Module 04:  What (1)
Module 05:  is (1)
Module 06:  artificial (1)
Module 07:  cognition (1)
Module 08:  ? (1)
Module 09:  My (2430) I (1003)
2017-01-17 23:12:40:629: Confabulated next symbol: goal
Module 03:  What (1)
Module 04:  is (1)
Module 05:  artificial (1)
Module 06:  cognition (1)
Module 07:  ? (1)
Module 08:  My (1)
Module 09:  goal (3992) name (2960)
Module 10:  is (3904) ? (936)
Module 11:  to (3096) Dyz (3096) My (1866) I (1003) your (875)
Module 12:  model (3096) Lecticus (3096) name (2520) goal (2520) am (1340) ... [1]
Module 13:  is (3368) reality (3096) ? (2406) an (1950) created (1584) ... [1]
Module 14:  through (3612) My (3486) to (2580) Dyz (2580) artificial (2520) ... [4]
Module 15:  interactions (4128) name (3528) goal (3528) model (3096) Lecticus (3096) ... [5]
Module 16:  is (4848) with (4128) reality (3612) van (3096) . (3012) ... [5]
2017-01-17 23:12:40:631: Confabulated next symbol: is
Module 02:  What (1)
Module 03:  is (1)
Module 04:  artificial (1)
Module 05:  cognition (1)
Module 06:  ? (1)
Module 07:  My (1)
Module 08:  goal (1)

[ ... ]

Module 09:  with (4128)
2017-01-17 23:12:40:674: Confabulated next symbol: people
Module 01:  goal (1)
Module 02:  is (1)
Module 03:  to (1)
Module 04:  model (1)
Module 05:  reality (1)
Module 06:  through (1)
Module 07:  interactions (1)
Module 08:  with (1)
Module 09:  people (4128)
2017-01-17 23:12:40:678: Confabulated next symbol: .
Module 01:  is (1)
Module 02:  to (1)
Module 03:  model (1)
Module 04:  reality (1)
Module 05:  through (1)
Module 06:  interactions (1)
Module 07:  with (1)
Module 08:  people (1)
Module 09:  . (1664)
2017-01-17 23:12:40:679: Failed to confabulate next symbol
Module 01:  to (1)
Module 02:  model (1)
Module 03:  reality (1)
Module 04:  through (1)
Module 05:  interactions (1)
Module 06:  with (1)
Module 07:  people (1)
Module 08:  . (1)
Confabulation output: My goal is to model reality through interactions with people . (88 ms)

Confabulation input sequence: What is artificial cognition? (context: Cognition)
2017-01-17 23:12:40:684: Confabulated next symbol: I
Module 04:  What (1)
Module 05:  is (1)
Module 06:  artificial (1)
Module 07:  cognition (1)
Module 08:  ? (1)
Module 09:  I (129)
2017-01-17 23:12:40:692: Confabulated next symbol: am
Module 03:  What (1)
Module 04:  is (1)
Module 05:  artificial (1)
Module 06:  cognition (1)
Module 07:  ? (1)
Module 08:  I (1)
Module 09:  am (268)
2017-01-17 23:12:40:696: Confabulated next symbol: an
Module 02:  What (1)
Module 03:  is (1)
Module 04:  artificial (1)
Module 05:  cognition (1)
Module 06:  ? (1)
Module 07:  I (1)
Module 08:  am (1)
Module 09:  an (390)
2017-01-17 23:12:40:702: Confabulated next symbol: artificial
Module 01:  What (1)
Module 02:  is (1)
Module 03:  artificial (1)
Module 04:  cognition (1)
Module 05:  ? (1)
Module 06:  I (1)
Module 07:  am (1)
Module 08:  an (1)
Module 09:  artificial (504)
2017-01-17 23:12:40:707: Confabulated next symbol: cognition
Module 01:  is (1)
Module 02:  artificial (1)
Module 03:  cognition (1)
Module 04:  ? (1)
Module 05:  I (1)
Module 06:  am (1)
Module 07:  an (1)
Module 08:  artificial (1)
Module 09:  cognition (615)
2017-01-17 23:12:40:711: Confabulated next symbol: .
Module 01:  artificial (1)
Module 02:  cognition (1)
Module 03:  ? (1)
Module 04:  I (1)
Module 05:  am (1)
Module 06:  an (1)
Module 07:  artificial (1)
Module 08:  cognition (1)
Module 09:  . (312)
2017-01-17 23:12:40:714: Failed to confabulate next symbol
Module 01:  cognition (1)
Module 02:  ? (1)
Module 03:  I (1)
Module 04:  am (1)
Module 05:  an (1)
Module 06:  artificial (1)
Module 07:  cognition (1)
Module 08:  . (1)
Confabulation output: I am an artificial cognition . (32 ms)

Confabulation input sequence: What is artificial cognition? (context: Name)
2017-01-17 23:12:40:718: Confabulated next symbol: My
Module 04:  What (1)
Module 05:  is (1)
Module 06:  artificial (1)
Module 07:  cognition (1)
Module 08:  ? (1)
Module 09:  My (396)
2017-01-17 23:12:40:720: Confabulated next symbol: name
Module 03:  What (1)
Module 04:  is (1)
Module 05:  artificial (1)
Module 06:  cognition (1)
Module 07:  ? (1)
Module 08:  My (1)
Module 09:  name (504)
2017-01-17 23:12:40:722: Confabulated next symbol: is
Module 02:  What (1)
Module 03:  is (1)
Module 04:  artificial (1)
Module 05:  cognition (1)
Module 06:  ? (1)
Module 07:  My (1)
Module 08:  name (1)
Module 09:  is (590) ? (117)
2017-01-17 23:12:40:724: Confabulated next symbol: Dyz
Module 01:  What (1)
Module 02:  is (1)
Module 03:  artificial (1)
Module 04:  cognition (1)
Module 05:  ? (1)
Module 06:  My (1)
Module 07:  name (1)
Module 08:  is (1)
Module 09:  Dyz (774) your (145)
2017-01-17 23:12:40:734: Confabulated next symbol: Lecticus
Module 01:  is (1)
Module 02:  artificial (1)
Module 03:  cognition (1)
Module 04:  ? (1)
Module 05:  My (1)
Module 06:  name (1)
Module 07:  is (1)
Module 08:  Dyz (1)
Module 09:  Lecticus (774)
2017-01-17 23:12:40:736: Confabulated next symbol: .
Module 01:  artificial (1)
Module 02:  cognition (1)
Module 03:  ? (1)
Module 04:  My (1)
Module 05:  name (1)
Module 06:  is (1)
Module 07:  Dyz (1)
Module 08:  Lecticus (1)
Module 09:  . (312)
2017-01-17 23:12:40:737: Failed to confabulate next symbol
Module 01:  cognition (1)
Module 02:  ? (1)
Module 03:  My (1)
Module 04:  name (1)
Module 05:  is (1)
Module 06:  Dyz (1)
Module 07:  Lecticus (1)
Module 08:  . (1)
Confabulation output: My name is Dyz Lecticus . (22 ms)
~~~~

Test results
------------
All 7 tests have been executed successfully (17 assertions).  
Total test duration: 1192 ms (total sleep duration: 600 ms).  
