Zeesoft Data Modelling Kit
==========================
The Zeesoft Data Modelling Kit (ZDMK) is an open source library for Java application development.
It provides support for versioned data model management.
The ZDK extends the [Zeesoft Development Kit](https://github.com/DyzLecticus/Zeesoft/tree/master/V3.0/ZDK).

**Release downloads**  
Click [here](https://github.com/DyzLecticus/Zeesoft/raw/master/V3.0/ZDMK/releases/zdmk-0.1.1.zip) to download the latest ZDMK release (version 0.1.1).
All ZDMK releases can be downloaded [here](https://github.com/DyzLecticus/Zeesoft/tree/master/V3.0/ZDMK/releases).
ZDMK releases contain;  
 * the ZDMK jar file.  
 * the corresponding ZDK jar file.  
 * this README file.  
 * Separate zip files containing the generated java documentation for each jar file.  
All jar files in the release include source code and build scripts.  

**Self documenting and self testing**  
The tests used to develop the ZDMK are also used to generate this README file.
Run the [ZDMK](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/ZDMK.java) class as a java application to print this documentation to the standard out.
Click [here](#test-results) to scroll down to the test result summary.

nl.zeesoft.zdmk.test.TestModel
------------------------------
This test shows how to create a *Model* instance and then apply some transformations to it.

**Example implementation**  
~~~~
// Create model
Model model = new Model();
// Create and apply transformation
model.applyTransformation(new AddPackage("new.package.name"));
~~~~

**Transformations**  
A *Model* supports the following transformations;  
 * [AddPackage](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/AddPackage.java)(name)  
   Adds a package to the model.  
  
 * [SetPackageName](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetPackageName.java)(name,newName)  
   Sets the name property of a package to the specified value.  
  
 * [RemovePackage](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/RemovePackage.java)(name)  
   Removes a package from the model.  
  
 * [RemovePackageAll](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/RemovePackageAll.java)  
   Removes all packages from the model.  
  
 * [AddClass](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/AddClass.java)(packageName,name)  
   Adds a class to a package.  
  
 * [SetClassAbstract](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetClassAbstract.java)(packageName,name,abstract)  
   Sets the abstract property of a class to the specified value.  
  
 * [SetClassExtendsClass](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetClassExtendsClass.java)(packageName,name)  
   Sets the extendsClass property of a class to the specified value.  
  
 * [SetClassName](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetClassName.java)(packageName,name,newName)  
   Sets the name property of a class to the specified value.  
  
 * [RemoveClass](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/RemoveClass.java)(packageName,name)  
   Removes a class from a package.  
  
 * [AddProperty](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/AddProperty.java)(className,packageName,name)  
   Adds a property to a class.  
  
 * [SetPropertyList](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetPropertyList.java)(className,packageName,name,list)  
   Sets the list property of a property to the specified value.  
  
 * [SetPropertyName](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetPropertyName.java)(className,packageName,name,newName)  
   Sets the list property of a property to the specified value.  
  
 * [SetPropertyType](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/SetPropertyType.java)(className,packageName,name,type)  
   Sets the type property of a property to the specified value.  
  
 * [RemoveProperty](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/RemoveProperty.java)(className,packageName,name)  
   Removes a property from a class.  
  
 * [IncrementVersion](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/IncrementVersion.java)  
   Creates a new version of the model containing all transformations needed to revert the model back to the current state.  
  
 * [RevertVersionBackward](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/RevertVersionBackward.java)(number)  
   Reverts the model state back to a specified model version. Removes all versions higher than the specified versions from the model.  
  
 * [RevertVersionChanges](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/RevertVersionChanges.java)  
   Reverts all changes made within the current model version.  
  
 * [ConvertModel](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/transformations/impl/ConvertModel.java)  
   Converts the current model to an object model. This means abstract classes are removed, extended class properties are made explicit, and class extensions are set to null.  

Class references;  
 * [TestModel](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/TestModel.java)
 * [Model](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/Model.java)

**Test output**  
The output of this test shows the model transformation log for all versions of the model and the resulting package structure.  
~~~~
Version: 0
2017-01-22 02:43:26:750 Applied transformation: AddPackage(name="new.package")
2017-01-22 02:43:26:788 Applied transformation: AddPackage(name="another.new.package")
2017-01-22 02:43:26:789 Failed to apply transformation: AddPackage(name="another.new.package"), error: Package another.new.package already exists
2017-01-22 02:43:26:789 Failed to apply transformation: SetPackageName(name="new.package",newName="another.new.package"), error: Package another.new.package already exists
2017-01-22 02:43:26:790 Applied transformation: SetPackageName(name="new.package",newName="new.package.newName")
2017-01-22 02:43:26:791 Applied transformation: RemovePackage(name="new.package.newName")
2017-01-22 02:43:26:791 Failed to apply transformation: RemovePackage(name="new.package.newName"), error: Package new.package.newName does not exist

Package: another.new.package

~~~~

nl.zeesoft.zdmk.test.TestModelVersioning
----------------------------------------
This test shows how to use *Model* model versioning.

**Example implementation**  
~~~~
// Create model
Model model = new Model();
// Create and apply transformation
model.applyTransformation(new AddPackage("new.package.name"));
// Increment model version
model.applyTransformation(new IncrementVersion());
// Create and apply transformation
model.applyTransformation(new AddPackage("test.package"));
// Revert current version changes
model.applyTransformation(new RevertVersionChanges());
// Revert version backward
model.applyTransformation(new RevertVersionBackward(1));
~~~~

Class references;  
 * [TestModelVersioning](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/TestModelVersioning.java)
 * [Model](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/Model.java)

**Test output**  
The output of this test shows two model transformation logs and corresponding package structures;  
 * Once after reverting the current version changes.  
 * Once after reverting back to version one of the model (leaving only the initial version).  
~~~~
Version: 0
2017-01-22 02:43:26:796 Applied transformation: AddPackage(name="test.package")
2017-01-22 02:43:26:799 Applied transformation: AddClass(packageName="test.package",name="testClassA")
2017-01-22 02:43:26:800 Applied transformation: AddClass(packageName="test.package",name="testClassB")

Version: 1
2017-01-22 02:43:26:800 Applied transformation: IncrementVersion()
2017-01-22 02:43:26:801 Applied transformation: AddPackage(name="another.test.package")
2017-01-22 02:43:26:802 Applied transformation: AddClass(packageName="another.test.package",name="testClassA")
2017-01-22 02:43:26:802 Applied transformation: AddClass(packageName="another.test.package",name="testClassB")

Version: 2
2017-01-22 02:43:26:803 Applied transformation: IncrementVersion()
2017-01-22 02:43:26:803 Applied transformation: AddPackage(name="yet.another.test.package")
2017-01-22 02:43:26:803 Applied transformation: AddClass(packageName="yet.another.test.package",name="testClassA")
2017-01-22 02:43:26:804 Applied transformation: AddClass(packageName="yet.another.test.package",name="testClassB")
2017-01-22 02:43:26:804 Applied transformation: RemoveClass(packageName="another.test.package",name="testClassA")
2017-01-22 02:43:26:805 Applied transformation: RemovePackageAll()
2017-01-22 02:43:26:805 Applied transformation: AddPackage(name="test.package")
2017-01-22 02:43:26:806 Applied transformation: AddClass(packageName="test.package",name="testClassA")
2017-01-22 02:43:26:806 Applied transformation: AddClass(packageName="test.package",name="testClassB")
2017-01-22 02:43:26:807 Applied transformation: AddPackage(name="another.test.package")
2017-01-22 02:43:26:807 Applied transformation: AddClass(packageName="another.test.package",name="testClassA")
2017-01-22 02:43:26:807 Applied transformation: AddClass(packageName="another.test.package",name="testClassB")
2017-01-22 02:43:26:808 Applied transformation: RevertVersionChanges()
2017-01-22 02:43:26:809 Failed to apply transformation: RevertVersionChanges(), error: The current model version does not contain any changes

Package: test.package
- Class: testClassA
- Class: testClassB
Package: another.test.package
- Class: testClassA
- Class: testClassB

Version: 0
2017-01-22 02:43:26:796 Applied transformation: AddPackage(name="test.package")
2017-01-22 02:43:26:799 Applied transformation: AddClass(packageName="test.package",name="testClassA")
2017-01-22 02:43:26:800 Applied transformation: AddClass(packageName="test.package",name="testClassB")
2017-01-22 02:43:26:847 Applied transformation: RevertVersionBackward(number="1")

Package: test.package
- Class: testClassA
- Class: testClassB

~~~~

nl.zeesoft.zdmk.test.TestModelSelf
----------------------------------
This test shows how to create a *ModelSelf* instance and initialize it.

**Example implementation**  
~~~~
// Create model
ModelSelf modelSelf = new ModelSelf();
// Initialize self model
modelSelf.initializeSelf();
~~~~

A *ModelSelf* extends the *Model* class. It contains a method that will generate a model that descibes itself.  

This test uses the *MockModelSelf*.

Class references;  
 * [TestModelSelf](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/TestModelSelf.java)
 * [MockModelSelf](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/MockModelSelf.java)
 * [ModelSelf](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/ModelSelf.java)
 * [Model](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/Model.java)

**Test output**  
The output of this test shows the model transformation log for all versions of the model and the resulting package structure.  
~~~~
Version: 0
2017-01-22 02:43:26:855 Applied transformation: AddPackage(name="nl.zeesoft.zdmk.model")
2017-01-22 02:43:26:855 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelNamedObject",abstract="true")
2017-01-22 02:43:26:857 Applied transformation: AddProperty(className="ModelNamedObject",packageName="nl.zeesoft.zdmk.model",name="name")
2017-01-22 02:43:26:857 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelPackage",extendsPackageName="nl.zeesoft.zdmk.model",extendsClassName="ModelNamedObject",abstract="false")
2017-01-22 02:43:26:858 Applied transformation: AddProperty(className="ModelPackage",packageName="nl.zeesoft.zdmk.model",name="classes",type="nl.zeesoft.zdmk.model.ModelClass",list="true")
2017-01-22 02:43:26:858 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelClass",extendsPackageName="nl.zeesoft.zdmk.model",extendsClassName="ModelNamedObject",abstract="false")
2017-01-22 02:43:26:859 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="properties",type="nl.zeesoft.zdmk.model.ModelProperty",list="true")
2017-01-22 02:43:26:859 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="extendsClass",type="nl.zeesoft.zdmk.model.ModelClass")
2017-01-22 02:43:26:860 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="abstract",type="java.lang.Boolean")
2017-01-22 02:43:26:860 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelProperty",extendsPackageName="nl.zeesoft.zdmk.model",extendsClassName="ModelNamedObject",abstract="false")
2017-01-22 02:43:26:861 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="type")
2017-01-22 02:43:26:862 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="list",type="java.lang.Boolean")

Version: 1
2017-01-22 02:43:26:863 Applied transformation: IncrementVersion()

Package: nl.zeesoft.zdmk.model
- Class: ModelNamedObject (abstract)
  - Property: name, type: java.lang.String
- Class: ModelPackage, extends: nl.zeesoft.zdmk.model.ModelNamedObject
  - Property: classes, type: List<nl.zeesoft.zdmk.model.ModelClass>
  - Property: name, type: java.lang.String (extends: nl.zeesoft.zdmk.model.ModelNamedObject:name)
- Class: ModelClass, extends: nl.zeesoft.zdmk.model.ModelNamedObject
  - Property: properties, type: List<nl.zeesoft.zdmk.model.ModelProperty>
  - Property: extendsClass, type: nl.zeesoft.zdmk.model.ModelClass
  - Property: abstract, type: java.lang.Boolean
  - Property: name, type: java.lang.String (extends: nl.zeesoft.zdmk.model.ModelNamedObject:name)
- Class: ModelProperty, extends: nl.zeesoft.zdmk.model.ModelNamedObject
  - Property: type, type: java.lang.String
  - Property: list, type: java.lang.Boolean
  - Property: name, type: java.lang.String (extends: nl.zeesoft.zdmk.model.ModelNamedObject:name)

~~~~

nl.zeesoft.zdmk.test.TestModelSelfConvertModel
----------------------------------------------
This test shows how to create a *ModelSelf* instance, initialize it and then convert it to an object model.

**Example implementation**  
~~~~
// Create model
ModelSelf modelSelf = new ModelSelf();
// Initialize self model
modelSelf.initializeSelf();
// Convert the model
modelSelf.applyTransformation(new ConvertModel());
~~~~

Class references;  
 * [TestModelSelfConvertModel](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/TestModelSelfConvertModel.java)
 * [MockModelSelf](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/test/MockModelSelf.java)
 * [ModelSelf](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/ModelSelf.java)
 * [Model](https://github.com/DyzLecticus/Zeesoft/blob/master/V3.0/ZDMK/src/nl/zeesoft/zdmk/model/Model.java)

**Test output**  
The output of this test shows the model transformation log for all versions of the model and the resulting package structure.  
~~~~
Version: 0
2017-01-22 02:43:26:951 Applied transformation: AddPackage(name="nl.zeesoft.zdmk.model")
2017-01-22 02:43:26:952 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelNamedObject",abstract="true")
2017-01-22 02:43:26:953 Applied transformation: AddProperty(className="ModelNamedObject",packageName="nl.zeesoft.zdmk.model",name="name")
2017-01-22 02:43:26:954 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelPackage",extendsPackageName="nl.zeesoft.zdmk.model",extendsClassName="ModelNamedObject",abstract="false")
2017-01-22 02:43:26:954 Applied transformation: AddProperty(className="ModelPackage",packageName="nl.zeesoft.zdmk.model",name="classes",type="nl.zeesoft.zdmk.model.ModelClass",list="true")
2017-01-22 02:43:26:955 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelClass",extendsPackageName="nl.zeesoft.zdmk.model",extendsClassName="ModelNamedObject",abstract="false")
2017-01-22 02:43:26:955 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="properties",type="nl.zeesoft.zdmk.model.ModelProperty",list="true")
2017-01-22 02:43:26:956 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="extendsClass",type="nl.zeesoft.zdmk.model.ModelClass")
2017-01-22 02:43:26:956 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="abstract",type="java.lang.Boolean")
2017-01-22 02:43:26:956 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelProperty",extendsPackageName="nl.zeesoft.zdmk.model",extendsClassName="ModelNamedObject",abstract="false")
2017-01-22 02:43:26:957 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="type")
2017-01-22 02:43:26:957 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="list",type="java.lang.Boolean")

Version: 1
2017-01-22 02:43:26:958 Applied transformation: IncrementVersion()
2017-01-22 02:43:26:959 Applied transformation: RemovePackageAll()
2017-01-22 02:43:26:959 Applied transformation: AddPackage(name="nl.zeesoft.zdmk.model")
2017-01-22 02:43:26:960 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelPackage")
2017-01-22 02:43:26:960 Applied transformation: AddProperty(className="ModelPackage",packageName="nl.zeesoft.zdmk.model",name="classes",type="nl.zeesoft.zdmk.model.ModelClass",list="true")
2017-01-22 02:43:26:961 Applied transformation: AddProperty(className="ModelPackage",packageName="nl.zeesoft.zdmk.model",name="name",type="java.lang.String",list="false")
2017-01-22 02:43:26:961 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelClass")
2017-01-22 02:43:26:961 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="properties",type="nl.zeesoft.zdmk.model.ModelProperty",list="true")
2017-01-22 02:43:26:962 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="extendsClass",type="nl.zeesoft.zdmk.model.ModelClass",list="false")
2017-01-22 02:43:26:962 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="abstract",type="java.lang.Boolean",list="false")
2017-01-22 02:43:26:962 Applied transformation: AddProperty(className="ModelClass",packageName="nl.zeesoft.zdmk.model",name="name",type="java.lang.String",list="false")
2017-01-22 02:43:26:963 Applied transformation: AddClass(packageName="nl.zeesoft.zdmk.model",name="ModelProperty")
2017-01-22 02:43:26:963 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="type",type="java.lang.String",list="false")
2017-01-22 02:43:26:964 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="list",type="java.lang.Boolean",list="false")
2017-01-22 02:43:26:964 Applied transformation: AddProperty(className="ModelProperty",packageName="nl.zeesoft.zdmk.model",name="name",type="java.lang.String",list="false")
2017-01-22 02:43:26:964 Applied transformation: ConvertModel()

Package: nl.zeesoft.zdmk.model
- Class: ModelPackage
  - Property: classes, type: List<nl.zeesoft.zdmk.model.ModelClass>
  - Property: name, type: java.lang.String
- Class: ModelClass
  - Property: properties, type: List<nl.zeesoft.zdmk.model.ModelProperty>
  - Property: extendsClass, type: nl.zeesoft.zdmk.model.ModelClass
  - Property: abstract, type: java.lang.Boolean
  - Property: name, type: java.lang.String
- Class: ModelProperty
  - Property: type, type: java.lang.String
  - Property: list, type: java.lang.Boolean
  - Property: name, type: java.lang.String

~~~~

Test results
------------
All 4 tests have been executed successfully (32 assertions).  
Total test duration: 357 ms (total sleep duration: 0 ms).  
